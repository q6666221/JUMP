﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Home
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuBox = New System.Windows.Forms.Panel()
        Me.Confirm = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Product = New System.Windows.Forms.Button()
        Me.NameText = New System.Windows.Forms.TextBox()
        Me.MarginBottonBox = New System.Windows.Forms.Panel()
        Me.MarginTopBox = New System.Windows.Forms.Panel()
        Me.MarginRigntBox = New System.Windows.Forms.Panel()
        Me.MarginLeftBox = New System.Windows.Forms.Panel()
        Me.RepBox = New System.Windows.Forms.Panel()
        Me.TittleBox = New System.Windows.Forms.Panel()
        Me.ReportTittle = New System.Windows.Forms.Label()
        Me.CtlBox = New System.Windows.Forms.Panel()
        Me.MinButton = New System.Windows.Forms.Button()
        Me.MaxButton = New System.Windows.Forms.Button()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.FucBox = New System.Windows.Forms.Panel()
        Me.Insert = New System.Windows.Forms.Button()
        Me.ProTittleBox = New System.Windows.Forms.Panel()
        Me.FucLabel = New System.Windows.Forms.Label()
        Me.ConTittleBox = New System.Windows.Forms.Panel()
        Me.FinishStateLabel = New System.Windows.Forms.Label()
        Me.ReportDetailBox = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Report_Content = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Reports_Detail = New System.Windows.Forms.DataGridView()
        Me.dates = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.weeks = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.start_time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.end_time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.worktime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.reports_content = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Submit_Button = New System.Windows.Forms.Button()
        Me.Company_Info = New System.Windows.Forms.DataGridView()
        Me.com_info = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.com_select = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Seal_Datagridview = New System.Windows.Forms.DataGridView()
        Me.minister = New System.Windows.Forms.DataGridViewImageColumn()
        Me.supervisor = New System.Windows.Forms.DataGridViewImageColumn()
        Me.project_administrator = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.reports = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Report_Date = New System.Windows.Forms.TextBox()
        Me.Commute = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Excel_Button = New System.Windows.Forms.Button()
        Me.MenuBox.SuspendLayout()
        Me.TittleBox.SuspendLayout()
        Me.CtlBox.SuspendLayout()
        Me.FucBox.SuspendLayout()
        Me.ProTittleBox.SuspendLayout()
        Me.ConTittleBox.SuspendLayout()
        Me.ReportDetailBox.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel13.SuspendLayout()
        CType(Me.Reports_Detail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Company_Info, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seal_Datagridview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuBox
        '
        Me.MenuBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.MenuBox.Controls.Add(Me.Confirm)
        Me.MenuBox.Controls.Add(Me.Panel1)
        Me.MenuBox.Controls.Add(Me.Product)
        Me.MenuBox.Controls.Add(Me.NameText)
        Me.MenuBox.Controls.Add(Me.MarginBottonBox)
        Me.MenuBox.Controls.Add(Me.MarginTopBox)
        Me.MenuBox.Controls.Add(Me.MarginRigntBox)
        Me.MenuBox.Controls.Add(Me.MarginLeftBox)
        Me.MenuBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuBox.Location = New System.Drawing.Point(0, 0)
        Me.MenuBox.Margin = New System.Windows.Forms.Padding(2)
        Me.MenuBox.Name = "MenuBox"
        Me.MenuBox.Size = New System.Drawing.Size(52, 640)
        Me.MenuBox.TabIndex = 0
        '
        'Confirm
        '
        Me.Confirm.Dock = System.Windows.Forms.DockStyle.Top
        Me.Confirm.FlatAppearance.BorderSize = 0
        Me.Confirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Confirm.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.Confirm.Location = New System.Drawing.Point(4, 83)
        Me.Confirm.Name = "Confirm"
        Me.Confirm.Size = New System.Drawing.Size(44, 28)
        Me.Confirm.TabIndex = 4
        Me.Confirm.Text = "承認"
        Me.Confirm.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(4, 73)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(44, 10)
        Me.Panel1.TabIndex = 0
        '
        'Product
        '
        Me.Product.Dock = System.Windows.Forms.DockStyle.Top
        Me.Product.FlatAppearance.BorderSize = 0
        Me.Product.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Product.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.Product.Location = New System.Drawing.Point(4, 45)
        Me.Product.Name = "Product"
        Me.Product.Size = New System.Drawing.Size(44, 28)
        Me.Product.TabIndex = 3
        Me.Product.Text = "作成"
        Me.Product.UseVisualStyleBackColor = True
        '
        'NameText
        '
        Me.NameText.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.NameText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.NameText.Dock = System.Windows.Forms.DockStyle.Top
        Me.NameText.Enabled = False
        Me.NameText.Font = New System.Drawing.Font("MS UI Gothic", 8.0!)
        Me.NameText.ForeColor = System.Drawing.SystemColors.Window
        Me.NameText.Location = New System.Drawing.Point(4, 20)
        Me.NameText.Multiline = True
        Me.NameText.Name = "NameText"
        Me.NameText.Size = New System.Drawing.Size(44, 25)
        Me.NameText.TabIndex = 5
        Me.NameText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MarginBottonBox
        '
        Me.MarginBottonBox.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MarginBottonBox.Location = New System.Drawing.Point(4, 636)
        Me.MarginBottonBox.Name = "MarginBottonBox"
        Me.MarginBottonBox.Size = New System.Drawing.Size(44, 4)
        Me.MarginBottonBox.TabIndex = 2
        '
        'MarginTopBox
        '
        Me.MarginTopBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.MarginTopBox.Location = New System.Drawing.Point(4, 0)
        Me.MarginTopBox.Name = "MarginTopBox"
        Me.MarginTopBox.Size = New System.Drawing.Size(44, 20)
        Me.MarginTopBox.TabIndex = 2
        '
        'MarginRigntBox
        '
        Me.MarginRigntBox.Dock = System.Windows.Forms.DockStyle.Right
        Me.MarginRigntBox.Location = New System.Drawing.Point(48, 0)
        Me.MarginRigntBox.Name = "MarginRigntBox"
        Me.MarginRigntBox.Size = New System.Drawing.Size(4, 640)
        Me.MarginRigntBox.TabIndex = 2
        '
        'MarginLeftBox
        '
        Me.MarginLeftBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.MarginLeftBox.Location = New System.Drawing.Point(0, 0)
        Me.MarginLeftBox.Name = "MarginLeftBox"
        Me.MarginLeftBox.Size = New System.Drawing.Size(4, 640)
        Me.MarginLeftBox.TabIndex = 0
        '
        'RepBox
        '
        Me.RepBox.AutoScroll = True
        Me.RepBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(189, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.RepBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.RepBox.Location = New System.Drawing.Point(52, 60)
        Me.RepBox.Margin = New System.Windows.Forms.Padding(2)
        Me.RepBox.Name = "RepBox"
        Me.RepBox.Size = New System.Drawing.Size(164, 580)
        Me.RepBox.TabIndex = 1
        '
        'TittleBox
        '
        Me.TittleBox.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TittleBox.Controls.Add(Me.ReportTittle)
        Me.TittleBox.Controls.Add(Me.CtlBox)
        Me.TittleBox.Controls.Add(Me.FucBox)
        Me.TittleBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.TittleBox.Location = New System.Drawing.Point(52, 0)
        Me.TittleBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TittleBox.Name = "TittleBox"
        Me.TittleBox.Size = New System.Drawing.Size(947, 60)
        Me.TittleBox.TabIndex = 2
        '
        'ReportTittle
        '
        Me.ReportTittle.AutoSize = True
        Me.ReportTittle.Location = New System.Drawing.Point(179, 36)
        Me.ReportTittle.Name = "ReportTittle"
        Me.ReportTittle.Size = New System.Drawing.Size(0, 12)
        Me.ReportTittle.TabIndex = 4
        '
        'CtlBox
        '
        Me.CtlBox.Controls.Add(Me.MinButton)
        Me.CtlBox.Controls.Add(Me.MaxButton)
        Me.CtlBox.Controls.Add(Me.CloseButton)
        Me.CtlBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.CtlBox.Location = New System.Drawing.Point(164, 0)
        Me.CtlBox.Margin = New System.Windows.Forms.Padding(2)
        Me.CtlBox.Name = "CtlBox"
        Me.CtlBox.Size = New System.Drawing.Size(783, 25)
        Me.CtlBox.TabIndex = 3
        '
        'MinButton
        '
        Me.MinButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.MinButton.FlatAppearance.BorderSize = 0
        Me.MinButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MinButton.Location = New System.Drawing.Point(681, 0)
        Me.MinButton.Margin = New System.Windows.Forms.Padding(2)
        Me.MinButton.Name = "MinButton"
        Me.MinButton.Size = New System.Drawing.Size(34, 25)
        Me.MinButton.TabIndex = 2
        Me.MinButton.Text = "Min"
        Me.MinButton.UseVisualStyleBackColor = True
        '
        'MaxButton
        '
        Me.MaxButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.MaxButton.FlatAppearance.BorderSize = 0
        Me.MaxButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MaxButton.Location = New System.Drawing.Point(715, 0)
        Me.MaxButton.Margin = New System.Windows.Forms.Padding(2)
        Me.MaxButton.Name = "MaxButton"
        Me.MaxButton.Size = New System.Drawing.Size(34, 25)
        Me.MaxButton.TabIndex = 1
        Me.MaxButton.Text = "Max"
        Me.MaxButton.UseVisualStyleBackColor = True
        '
        'CloseButton
        '
        Me.CloseButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.CloseButton.FlatAppearance.BorderSize = 0
        Me.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CloseButton.Location = New System.Drawing.Point(749, 0)
        Me.CloseButton.Margin = New System.Windows.Forms.Padding(2)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(34, 25)
        Me.CloseButton.TabIndex = 0
        Me.CloseButton.Text = "Clo"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'FucBox
        '
        Me.FucBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.FucBox.Controls.Add(Me.Insert)
        Me.FucBox.Controls.Add(Me.ProTittleBox)
        Me.FucBox.Controls.Add(Me.ConTittleBox)
        Me.FucBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.FucBox.Location = New System.Drawing.Point(0, 0)
        Me.FucBox.Margin = New System.Windows.Forms.Padding(2)
        Me.FucBox.Name = "FucBox"
        Me.FucBox.Size = New System.Drawing.Size(164, 60)
        Me.FucBox.TabIndex = 1
        '
        'Insert
        '
        Me.Insert.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.Insert.FlatAppearance.BorderSize = 0
        Me.Insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Insert.Location = New System.Drawing.Point(0, 25)
        Me.Insert.Name = "Insert"
        Me.Insert.Size = New System.Drawing.Size(164, 35)
        Me.Insert.TabIndex = 1
        Me.Insert.Text = "追加"
        Me.Insert.UseVisualStyleBackColor = False
        '
        'ProTittleBox
        '
        Me.ProTittleBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.ProTittleBox.Controls.Add(Me.FucLabel)
        Me.ProTittleBox.Location = New System.Drawing.Point(0, 0)
        Me.ProTittleBox.Name = "ProTittleBox"
        Me.ProTittleBox.Size = New System.Drawing.Size(164, 25)
        Me.ProTittleBox.TabIndex = 3
        '
        'FucLabel
        '
        Me.FucLabel.AutoSize = True
        Me.FucLabel.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.0!)
        Me.FucLabel.Location = New System.Drawing.Point(3, 5)
        Me.FucLabel.Name = "FucLabel"
        Me.FucLabel.Size = New System.Drawing.Size(105, 14)
        Me.FucLabel.TabIndex = 0
        Me.FucLabel.Text = "作業報告作成："
        '
        'ConTittleBox
        '
        Me.ConTittleBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.ConTittleBox.Controls.Add(Me.FinishStateLabel)
        Me.ConTittleBox.Location = New System.Drawing.Point(0, 0)
        Me.ConTittleBox.Name = "ConTittleBox"
        Me.ConTittleBox.Size = New System.Drawing.Size(164, 25)
        Me.ConTittleBox.TabIndex = 0
        '
        'FinishStateLabel
        '
        Me.FinishStateLabel.AutoSize = True
        Me.FinishStateLabel.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.0!)
        Me.FinishStateLabel.Location = New System.Drawing.Point(3, 5)
        Me.FinishStateLabel.Name = "FinishStateLabel"
        Me.FinishStateLabel.Size = New System.Drawing.Size(105, 14)
        Me.FinishStateLabel.TabIndex = 0
        Me.FinishStateLabel.Text = "作業報告承認："
        '
        'ReportDetailBox
        '
        Me.ReportDetailBox.AutoScroll = True
        Me.ReportDetailBox.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ReportDetailBox.Controls.Add(Me.TableLayoutPanel1)
        Me.ReportDetailBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportDetailBox.Location = New System.Drawing.Point(216, 60)
        Me.ReportDetailBox.Margin = New System.Windows.Forms.Padding(2)
        Me.ReportDetailBox.Name = "ReportDetailBox"
        Me.ReportDetailBox.Size = New System.Drawing.Size(783, 580)
        Me.ReportDetailBox.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 14
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 38.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 94.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 17.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 11, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 4, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel13, 2, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.Submit_Button, 12, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Company_Info, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 10, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Seal_Datagridview, 10, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 10, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.reports, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Report_Date, 7, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Commute, 8, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 7, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Excel_Button, 10, 12)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 64
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(764, 1083)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'Label2
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label2, 2)
        Me.Label2.Location = New System.Drawing.Point(563, 0)
        Me.Label2.Margin = New System.Windows.Forms.Padding(0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(184, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Rev 2016/04/01"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label6, 2)
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Location = New System.Drawing.Point(109, 226)
        Me.Label6.Margin = New System.Windows.Forms.Padding(0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 18)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "作　業　報　告　欄"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel13
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel13, 11)
        Me.Panel13.Controls.Add(Me.Report_Content)
        Me.Panel13.Controls.Add(Me.Label7)
        Me.Panel13.Controls.Add(Me.Reports_Detail)
        Me.Panel13.Location = New System.Drawing.Point(30, 266)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel13.Name = "Panel13"
        Me.TableLayoutPanel1.SetRowSpan(Me.Panel13, 44)
        Me.Panel13.Size = New System.Drawing.Size(716, 774)
        Me.Panel13.TabIndex = 14
        '
        'Report_Content
        '
        Me.Report_Content.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Report_Content.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Report_Content.Location = New System.Drawing.Point(0, 627)
        Me.Report_Content.Margin = New System.Windows.Forms.Padding(0)
        Me.Report_Content.Multiline = True
        Me.Report_Content.Name = "Report_Content"
        Me.Report_Content.Size = New System.Drawing.Size(716, 147)
        Me.Report_Content.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(0, 609)
        Me.Label7.Margin = New System.Windows.Forms.Padding(0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 18)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "[特記事項］"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Reports_Detail
        '
        Me.Reports_Detail.AllowUserToAddRows = False
        Me.Reports_Detail.AllowUserToDeleteRows = False
        Me.Reports_Detail.AllowUserToResizeColumns = False
        Me.Reports_Detail.AllowUserToResizeRows = False
        Me.Reports_Detail.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Reports_Detail.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Reports_Detail.ColumnHeadersHeight = 44
        Me.Reports_Detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Reports_Detail.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dates, Me.weeks, Me.start_time, Me.end_time, Me.worktime, Me.reports_content})
        Me.Reports_Detail.Location = New System.Drawing.Point(0, 0)
        Me.Reports_Detail.Margin = New System.Windows.Forms.Padding(0)
        Me.Reports_Detail.Name = "Reports_Detail"
        Me.Reports_Detail.RowHeadersVisible = False
        Me.Reports_Detail.RowHeadersWidth = 51
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Reports_Detail.RowsDefaultCellStyle = DataGridViewCellStyle7
        Me.Reports_Detail.RowTemplate.Height = 17
        Me.Reports_Detail.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Reports_Detail.Size = New System.Drawing.Size(716, 608)
        Me.Reports_Detail.TabIndex = 13
        '
        'dates
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dates.DefaultCellStyle = DataGridViewCellStyle2
        Me.dates.Frozen = True
        Me.dates.HeaderText = "日付"
        Me.dates.MinimumWidth = 6
        Me.dates.Name = "dates"
        Me.dates.ReadOnly = True
        Me.dates.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dates.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.dates.Width = 40
        '
        'weeks
        '
        Me.weeks.HeaderText = "曜日"
        Me.weeks.MinimumWidth = 6
        Me.weeks.Name = "weeks"
        Me.weeks.ReadOnly = True
        Me.weeks.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.weeks.Width = 40
        '
        'start_time
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.start_time.DefaultCellStyle = DataGridViewCellStyle3
        Me.start_time.HeaderText = "開始"
        Me.start_time.MinimumWidth = 6
        Me.start_time.Name = "start_time"
        Me.start_time.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.start_time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.start_time.Width = 63
        '
        'end_time
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.end_time.DefaultCellStyle = DataGridViewCellStyle4
        Me.end_time.HeaderText = "終了"
        Me.end_time.MinimumWidth = 6
        Me.end_time.Name = "end_time"
        Me.end_time.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.end_time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.end_time.Width = 63
        '
        'worktime
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.worktime.DefaultCellStyle = DataGridViewCellStyle5
        Me.worktime.HeaderText = "工数"
        Me.worktime.MinimumWidth = 6
        Me.worktime.Name = "worktime"
        Me.worktime.ReadOnly = True
        Me.worktime.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.worktime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.worktime.Width = 63
        '
        'reports_content
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.reports_content.DefaultCellStyle = DataGridViewCellStyle6
        Me.reports_content.HeaderText = "作業内容"
        Me.reports_content.MinimumWidth = 6
        Me.reports_content.Name = "reports_content"
        Me.reports_content.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.reports_content.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.reports_content.Width = 445
        '
        'Submit_Button
        '
        Me.Submit_Button.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Submit_Button.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Submit_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Submit_Button.Location = New System.Drawing.Point(653, 244)
        Me.Submit_Button.Margin = New System.Windows.Forms.Padding(0)
        Me.Submit_Button.Name = "Submit_Button"
        Me.Submit_Button.Size = New System.Drawing.Size(94, 22)
        Me.Submit_Button.TabIndex = 15
        Me.Submit_Button.Text = "保　存"
        Me.Submit_Button.UseVisualStyleBackColor = False
        '
        'Company_Info
        '
        Me.Company_Info.AllowUserToAddRows = False
        Me.Company_Info.AllowUserToDeleteRows = False
        Me.Company_Info.AllowUserToResizeColumns = False
        Me.Company_Info.AllowUserToResizeRows = False
        Me.Company_Info.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.Company_Info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Company_Info.ColumnHeadersVisible = False
        Me.Company_Info.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.com_info, Me.com_select})
        Me.TableLayoutPanel1.SetColumnSpan(Me.Company_Info, 7)
        Me.Company_Info.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Company_Info.Location = New System.Drawing.Point(30, 118)
        Me.Company_Info.Margin = New System.Windows.Forms.Padding(0)
        Me.Company_Info.Name = "Company_Info"
        Me.Company_Info.ReadOnly = True
        Me.Company_Info.RowHeadersVisible = False
        Me.Company_Info.RowHeadersWidth = 51
        Me.TableLayoutPanel1.SetRowSpan(Me.Company_Info, 4)
        Me.Company_Info.RowTemplate.Height = 17
        Me.Company_Info.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Company_Info.Size = New System.Drawing.Size(417, 72)
        Me.Company_Info.TabIndex = 3
        '
        'com_info
        '
        Me.com_info.HeaderText = "com_info"
        Me.com_info.MinimumWidth = 6
        Me.com_info.Name = "com_info"
        Me.com_info.ReadOnly = True
        Me.com_info.Width = 143
        '
        'com_select
        '
        Me.com_select.HeaderText = "com_select"
        Me.com_select.MinimumWidth = 6
        Me.com_select.Name = "com_select"
        Me.com_select.ReadOnly = True
        Me.com_select.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.com_select.Width = 271
        '
        'Label1
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label1, 3)
        Me.Label1.Location = New System.Drawing.Point(473, 64)
        Me.Label1.Margin = New System.Windows.Forms.Padding(0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 18)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "「検収印押印欄」"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Seal_Datagridview
        '
        Me.Seal_Datagridview.AllowUserToAddRows = False
        Me.Seal_Datagridview.AllowUserToDeleteRows = False
        Me.Seal_Datagridview.AllowUserToResizeColumns = False
        Me.Seal_Datagridview.AllowUserToResizeRows = False
        Me.Seal_Datagridview.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Seal_Datagridview.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.Seal_Datagridview.ColumnHeadersHeight = 22
        Me.Seal_Datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Seal_Datagridview.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.minister, Me.supervisor, Me.project_administrator})
        Me.TableLayoutPanel1.SetColumnSpan(Me.Seal_Datagridview, 3)
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Seal_Datagridview.DefaultCellStyle = DataGridViewCellStyle9
        Me.Seal_Datagridview.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Seal_Datagridview.GridColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Seal_Datagridview.Location = New System.Drawing.Point(473, 100)
        Me.Seal_Datagridview.Margin = New System.Windows.Forms.Padding(0)
        Me.Seal_Datagridview.Name = "Seal_Datagridview"
        Me.Seal_Datagridview.RowHeadersVisible = False
        Me.Seal_Datagridview.RowHeadersWidth = 51
        Me.TableLayoutPanel1.SetRowSpan(Me.Seal_Datagridview, 6)
        Me.Seal_Datagridview.RowTemplate.Height = 85
        Me.Seal_Datagridview.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Seal_Datagridview.Size = New System.Drawing.Size(274, 108)
        Me.Seal_Datagridview.TabIndex = 13
        '
        'minister
        '
        Me.minister.HeaderText = "営業"
        Me.minister.MinimumWidth = 6
        Me.minister.Name = "minister"
        Me.minister.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.minister.Width = 80
        '
        'supervisor
        '
        Me.supervisor.HeaderText = "リーダー"
        Me.supervisor.MinimumWidth = 6
        Me.supervisor.Name = "supervisor"
        Me.supervisor.Width = 80
        '
        'project_administrator
        '
        Me.project_administrator.HeaderText = "ﾌﾟﾛｼﾞｪｸﾄ管理者"
        Me.project_administrator.MinimumWidth = 6
        Me.project_administrator.Name = "project_administrator"
        Me.project_administrator.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.project_administrator.Width = 112
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label4, 3)
        Me.Label4.Location = New System.Drawing.Point(473, 82)
        Me.Label4.Margin = New System.Windows.Forms.Padding(0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(274, 18)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "依頼元押印欄"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'reports
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.reports, 3)
        Me.reports.Font = New System.Drawing.Font("SimSun", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.reports.Location = New System.Drawing.Point(237, 20)
        Me.reports.Margin = New System.Windows.Forms.Padding(0)
        Me.reports.Name = "reports"
        Me.reports.Size = New System.Drawing.Size(210, 44)
        Me.reports.TabIndex = 2
        Me.reports.Text = "作　業　報　告　書"
        Me.reports.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label3, 2)
        Me.Label3.Location = New System.Drawing.Point(30, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "(標準版)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Report_Date
        '
        Me.Report_Date.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Report_Date.Location = New System.Drawing.Point(301, 82)
        Me.Report_Date.Margin = New System.Windows.Forms.Padding(0)
        Me.Report_Date.Name = "Report_Date"
        Me.Report_Date.ReadOnly = True
        Me.Report_Date.Size = New System.Drawing.Size(86, 19)
        Me.Report_Date.TabIndex = 18
        Me.Report_Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Commute
        '
        Me.Commute.Font = New System.Drawing.Font("SimSun", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Commute.FormattingEnabled = True
        Me.Commute.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Commute.ItemHeight = 14
        Me.Commute.Location = New System.Drawing.Point(387, 244)
        Me.Commute.Margin = New System.Windows.Forms.Padding(0)
        Me.Commute.Name = "Commute"
        Me.Commute.Size = New System.Drawing.Size(60, 22)
        Me.Commute.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label5.Location = New System.Drawing.Point(301, 244)
        Me.Label5.Margin = New System.Windows.Forms.Padding(0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 22)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "開始時間："
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Excel_Button
        '
        Me.Excel_Button.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Excel_Button.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Excel_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Excel_Button.Location = New System.Drawing.Point(473, 244)
        Me.Excel_Button.Margin = New System.Windows.Forms.Padding(0)
        Me.Excel_Button.Name = "Excel_Button"
        Me.Excel_Button.Size = New System.Drawing.Size(90, 22)
        Me.Excel_Button.TabIndex = 15
        Me.Excel_Button.Text = "エクセル出力"
        Me.Excel_Button.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 640)
        Me.ControlBox = False
        Me.Controls.Add(Me.ReportDetailBox)
        Me.Controls.Add(Me.RepBox)
        Me.Controls.Add(Me.TittleBox)
        Me.Controls.Add(Me.MenuBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MinimumSize = New System.Drawing.Size(900, 581)
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.MenuBox.ResumeLayout(False)
        Me.MenuBox.PerformLayout()
        Me.TittleBox.ResumeLayout(False)
        Me.TittleBox.PerformLayout()
        Me.CtlBox.ResumeLayout(False)
        Me.FucBox.ResumeLayout(False)
        Me.ProTittleBox.ResumeLayout(False)
        Me.ProTittleBox.PerformLayout()
        Me.ConTittleBox.ResumeLayout(False)
        Me.ConTittleBox.PerformLayout()
        Me.ReportDetailBox.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        CType(Me.Reports_Detail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Company_Info, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seal_Datagridview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MenuBox As Panel
    Friend WithEvents RepBox As Panel
    Friend WithEvents TittleBox As Panel
    Friend WithEvents ReportDetailBox As Panel
    Friend WithEvents MinButton As Button
    Friend WithEvents MaxButton As Button
    Friend WithEvents CloseButton As Button
    Friend WithEvents CtlBox As Panel
    Friend WithEvents FucBox As Panel
    Friend WithEvents ConTittleBox As Panel
    Friend WithEvents MarginLeftBox As Panel
    Friend WithEvents MarginRigntBox As Panel
    Friend WithEvents MarginBottonBox As Panel
    Friend WithEvents MarginTopBox As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Confirm As Button
    Friend WithEvents Product As Button
    Friend WithEvents FinishStateLabel As Label
    Friend WithEvents FucLabel As Label
    Friend WithEvents Insert As Button
    Friend WithEvents ProTittleBox As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Report_Content As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Reports_Detail As DataGridView
    Friend WithEvents Submit_Button As Button
    Friend WithEvents Company_Info As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Seal_Datagridview As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents reports As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Commute As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ReportTittle As Label
    Friend WithEvents Report_Date As TextBox
    Friend WithEvents dates As DataGridViewTextBoxColumn
    Friend WithEvents weeks As DataGridViewTextBoxColumn
    Friend WithEvents start_time As DataGridViewTextBoxColumn
    Friend WithEvents end_time As DataGridViewTextBoxColumn
    Friend WithEvents worktime As DataGridViewTextBoxColumn
    Friend WithEvents reports_content As DataGridViewTextBoxColumn
    Friend WithEvents Excel_Button As Button
    Friend WithEvents NameText As TextBox
    Friend WithEvents minister As DataGridViewImageColumn
    Friend WithEvents supervisor As DataGridViewImageColumn
    Friend WithEvents project_administrator As DataGridViewImageColumn
    Friend WithEvents com_info As DataGridViewTextBoxColumn
    Friend WithEvents com_select As DataGridViewTextBoxColumn
End Class
