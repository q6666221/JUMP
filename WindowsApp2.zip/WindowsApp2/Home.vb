﻿Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel
Imports Forms = System.Windows.Forms
Imports IO = System.IO
''' <summary>
''' 作業報告システムのホームページ
''' </summary>
Public Class Home

    ''' <summary>
    ''' ログインしたユーザー
    ''' </summary>
    Private employee As Employees
    ''' <summary>
    ''' コネクションの接続
    ''' </summary>
    Private conn As SqlConnection
    ''' <summary>
    ''' デフォルト印鑑イメージ
    ''' </summary>
    Private seal As Image = New Bitmap(80, 80)
    ''' <summary>
    ''' 修正可能フラグ
    ''' </summary>
    Private enableFlag = True
    'Private r_id As Integer

    Private ReportMap As New Hashtable

    ''' <summary>
    ''' 引数あるコンストラクタ
    ''' </summary>
    ''' <param name="conn"></param>
    ''' <param name="employee"></param>
    Public Sub New(conn As SqlConnection, employee As Employees)

        ' この呼び出しはデザイナーで必要です。
        InitializeComponent()

        ' InitializeComponent() 呼び出しの後で初期化を追加します。
        Me.employee = employee
        Me.conn = conn


    End Sub

    ''' <summary>
    ''' 作業報告ホームページのイニシャライズ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '氏名を取得する
        With NameText
            .Text = employee.e_name
        End With

        'メニューの権限判断
        If employee.p_id = 6 Then
            Confirm.Hide()
        End If

        '作業報告書の初期化
        ReportsBoxInit(Product, e)

        '印鑑の初期化
        Seal_Init()

        '一時的な非表示
        Label5.Hide()
        Commute.Hide()
    End Sub

    ''' <summary>
    ''' 印鑑の初期化
    ''' </summary>
    Private Sub Seal_Init()
        Seal_Datagridview.Rows.Clear()
        '印鑑欄のイニシャライズ
        Seal_Datagridview.Rows.Add(1)
        'Seal_Datagridview.CurrentRow.Height = 85
        Dim column1 = CType(Seal_Datagridview.Columns(0), DataGridViewImageColumn)
        Dim column2 = CType(Seal_Datagridview.Columns(1), DataGridViewImageColumn)
        Dim column3 = CType(Seal_Datagridview.Columns(2), DataGridViewImageColumn)
        column1.Image = Me.seal
        column2.Image = Me.seal
        column3.Image = Me.seal
    End Sub

    ''' <summary>
    ''' 作業報告書の初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ReportsBoxInit(sender As Object, e As EventArgs) _
        Handles Product.Click, Confirm.Click
        Select Case CType(sender, Button).Name
            '
            Case Product.Name
                enableFlag = True
                RepBox.Controls.Clear()
                Reports_Detail.ReadOnly = False
                Submit_Button.Text = "保　存"
                '作業報告作成の表示
                ShowProductCtl()
                Dim count = ProRepBox_Init()
                If count <> 0 Then

                    Submit_Button.Enabled = True
                    Dim firstBox = RepBox.Controls(RepBox.Controls.Count - 1)
                    Update_Click(firstBox, e)
                Else
                    Submit_Button.Enabled = False
                    Seal_Init()
                    Company_Info.Rows.Clear()
                    Reports_Detail.Rows.Clear()
                    Report_Date.Text = Nothing
                End If
            Case Confirm.Name
                enableFlag = False
                RepBox.Controls.Clear()
                Reports_Detail.ReadOnly = True
                Submit_Button.Text = "承　認"
                '作業報告承認の表示
                ShowConfirmCtl()
                Dim count = ConRepBox_Init()
                If count <> 0 Then
                    '初期化した時、一個目作業報告を表示
                    Submit_Button.Enabled = True
                    Dim firstBox = RepBox.Controls(RepBox.Controls.Count - 1)
                    Update_Click(firstBox, e)
                Else
                    '初期化した時、作業報告はない場合は、作業報告を表示しない
                    Submit_Button.Enabled = False
                    Seal_Init()
                    Company_Info.Rows.Clear()
                    Reports_Detail.Rows.Clear()
                    Report_Date.Text = Nothing
                End If
        End Select

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    Private Sub ShowProductCtl()
        ProTittleBox.BringToFront()
        ConTittleBox.SendToBack()
        Insert.Show()
    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    Private Sub ShowConfirmCtl()
        ConTittleBox.BringToFront()
        ProTittleBox.SendToBack()
        Insert.Hide()
    End Sub

    ''' <summary>
    ''' フォームの最小化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub MinButton_Click(sender As Object, e As EventArgs) Handles MinButton.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    ''' <summary>
    ''' フォームの最大化・元に戻す
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub MaxButton_Click(sender As Object, e As EventArgs) Handles MaxButton.Click
        If Me.WindowState <> FormWindowState.Maximized Then
            Me.WindowState = FormWindowState.Maximized
        Else
            Me.WindowState = FormWindowState.Normal
        End If
    End Sub

    ''' <summary>
    ''' フォームを閉じる
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Me.Close()
        Login.Close()
    End Sub

#Region "フォームの移動について"

    Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As IntPtr, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Boolean
    Public Declare Function ReleaseCapture Lib "user32" Alias "ReleaseCapture" () As Boolean
    Public Const WM_SYSCOMMAND = &H112
    Public Const SC_MOVE = &HF010&
    Public Const HTCAPTION = 2
    Private Sub Drag_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) _
        Handles TittleBox.MouseDown, CtlBox.MouseDown, FucBox.MouseDown
        ReleaseCapture()

        SendMessage(Me.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0)

    End Sub
#End Region

    ''' <summary>
    ''' 作業報告の追加
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Insert_Click(sender As Object, e As EventArgs) Handles Insert.Click
        Dim sql = "select max(r_date) r_date from reports where e_id = ?"
        Dim table = Tools.GetData(conn, sql, employee.e_id)

        '社員の入社時間
        Dim createTime = CDate(employee.create_time)

        '最近の作業報告作成の時間
        Dim max_date = table.Rows(0).Field(Of String)("r_date")

        '挿入操作についてのフラグ、trueの場合は操作する、逆は操作しない
        Dim exeFlag = True

        '作業報告存在の場合は、次の時間を取得する
        If max_date IsNot Nothing Then
            createTime = CDate(table.Rows(0).Field(Of String)("r_date")).AddMonths(1)

            '次の時間は大なり今の時間の場合、falseにフラゲを変換する
            If createTime > Date.Now Then
                exeFlag = False
            End If
        End If

        'フラグはtrueの場合、以下のコードを実行する、逆は実行しない
        If exeFlag Then
            '時間の年月日
            Dim r_date = createTime.ToShortDateString.Substring(0, 7)
            sql = "insert into reports (r_id,e_id,r_date,u_id) values (next value for reports_sequence,?,?,?)"
            Console.WriteLine("Reports表の中の影響される行目:" & Tools.SetData(conn, sql, employee.e_id, r_date, employee.u_id))
            sql = "select max(r_id) r_id from reports where e_id = ?"
            Dim r_id = Tools.GetData(conn, sql, employee.e_id).Rows(0).Field(Of Integer)("r_id")

            'データベースに複数のデータを入力する
            Dim days = Date.DaysInMonth(createTime.Year, createTime.Month)
            Dim value = ""
            For i = 0 To days - 1
                value &= "(" & r_id & ")"
                If i <> days - 1 Then
                    value &= ","
                End If
            Next
            sql = "insert into reports_detail (r_id) values " & value
            Console.WriteLine("ReportsDetail表の中の影響される行目：" & Tools.SetData(conn, sql))
            ReportsBoxInit(Product, e)
        Else
            MessageBox.Show("来月の作業報告作成できない!")
        End If
    End Sub

    ''' <summary>
    ''' 作業報告の詳細内容の表示
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Update_Click(sender As Object, e As EventArgs)
        Dim senderType = sender.GetType.Name

        Dim ctl = CType(sender, Control)
        If senderType = "Label" Then
            ctl = CType(sender, Control).Parent
        End If
        'CType(ReportMap(TableLayoutPanel1.Tag), Control).BackColor = Color.FromArgb(189, 190, 191)
        ctl.BackColor = Color.WhiteSmoke
        TableLayoutPanel1.Tag = ctl.Tag
        ReportTittle.Text = ctl.Controls(0).Text
        ShowReport(ctl)
    End Sub

    ''' <summary>
    ''' 作業報告のリストのカラー変換
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Color_MouseHover(sender As Object, e As EventArgs)

        Select Case sender.GetType.Name
            Case "Label"
                Dim ctl = CType(sender, Label).Parent
                ctl.BackColor = Color.WhiteSmoke
            Case "Panel"
                Dim ctl = CType(sender, Panel)
                ctl.BackColor = Color.WhiteSmoke
        End Select

    End Sub

    ''' <summary>
    ''' 作業報告のリストのカラーを戻る
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Color_MouseLeave(sender As Object, e As EventArgs)
        Select Case sender.GetType.Name
            Case "Label"
                Dim ctl = CType(sender, Label).Parent
                If ctl.BackColor = Color.WhiteSmoke Then
                    ctl.BackColor = Color.FromArgb(189, 190, 191)
                End If
            Case "Panel"
                Dim ctl = CType(sender, Panel)
                ctl.BackColor = Color.FromArgb(189, 190, 191)
        End Select
    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <returns></returns>
    Private Function ProRepBox_Init() As Integer
        RepBox.Controls.Clear()
        ReportMap.Clear()
        Dim Sql = "select r_id,r_date,sales_flag,com_flag from reports where e_id = ? order by r_date asc"
        Dim reports = Tools.GetData(conn, Sql, employee.e_id)
        For i = 0 To reports.Rows.Count - 1
            Dim row = reports.Rows(i)
            Dim r_date = CDate(row.Field(Of String)("r_date")).ToShortDateString

            Dim report = New Label With {
                .Text = r_date.Substring(0, 7),
                .Font = New Font("ＭＳ ゴシック", 10),
                .TextAlign = ContentAlignment.MiddleRight,
                .Location = New Point(0, 5),
                .Tag = row.Field(Of Integer)("r_id")
            }
            Dim panel As New Panel With {
                .Dock = DockStyle.Top,
                .Height = 30,
                .Tag = row.Field(Of Integer)("r_id")
            }
            panel.Controls.Add(report)
            Dim sales_flag = reports.Rows(i).Field(Of Boolean)("sales_flag")
            Dim com_flag = reports.Rows(i).Field(Of Boolean)("com_flag")
            If sales_flag OrElse com_flag Then
                Dim flag = New Label With {
                    .Text = "済",
                    .Font = New Font("ＭＳ ゴシック", 7),
                    .Location = New Point(50, 5),
                    .TextAlign = ContentAlignment.MiddleRight,
                    .Tag = row.Field(Of Integer)("r_id")
                }
                AddHandler flag.Click, AddressOf Update_Click
                AddHandler flag.MouseHover, AddressOf Color_MouseHover
                AddHandler flag.MouseLeave, AddressOf Color_MouseLeave
                panel.Controls.Add(flag)
            End If
            AddHandler report.Click, AddressOf Update_Click
            AddHandler report.MouseHover, AddressOf Color_MouseHover
            AddHandler report.MouseLeave, AddressOf Color_MouseLeave
            AddHandler panel.Click, AddressOf Update_Click
            AddHandler panel.MouseHover, AddressOf Color_MouseHover
            AddHandler panel.MouseLeave, AddressOf Color_MouseLeave
            RepBox.Controls.Add(panel)
            ReportMap.Add(row.Field(Of Integer)("r_id"), panel)
        Next
        Return reports.Rows.Count
    End Function

    Private Function ConRepBox_Init() As Integer
        RepBox.Controls.Clear()
        ReportMap.Clear()
        Dim Sql = "select r_id,r_date,sales_flag,com_flag,e.e_name from reports r left join employees e on r.e_id = e.e_id where e.m_id = ? order by r_date asc"
        Dim reports = Tools.GetData(conn, Sql, employee.e_id)
        For i = 0 To reports.Rows.Count - 1
            Dim row = reports.Rows(i)
            Dim r_id = row.Field(Of Integer)("r_id")
            Dim e_name = row.Field(Of String)("e_name")
            Dim r_date = CDate(row.Field(Of String)("r_date")).ToShortDateString
            Dim msg = e_name & r_date.Substring(0, 7)
            Dim report = New Label With {
                .Text = msg,
                .Font = New Font("ＭＳ ゴシック", 10),
                .Location = New Point(10, 5),
                .TextAlign = ContentAlignment.MiddleRight,
                .Tag = r_id
            }

            Dim panel As New Panel With {
                .Dock = DockStyle.Top,
                .Height = 30,
                .Tag = r_id
            }
            panel.Controls.Add(report)
            Dim sales_flag = reports.Rows(i).Field(Of Boolean)("sales_flag")
            Dim com_flag = reports.Rows(i).Field(Of Boolean)("com_flag")
            If sales_flag OrElse com_flag Then
                Dim flag = New Label With {
                    .Text = "済",
                    .Font = New Font("ＭＳ ゴシック", 7),
                    .TextAlign = ContentAlignment.MiddleRight,
                    .Location = New Point(50, 5),
                    .Tag = row.Field(Of Integer)("r_id")
                }
                AddHandler flag.Click, AddressOf Update_Click
                AddHandler flag.MouseHover, AddressOf Color_MouseHover
                AddHandler flag.MouseLeave, AddressOf Color_MouseLeave
                panel.Controls.Add(flag)
            End If

            AddHandler report.Click, AddressOf Update_Click
            AddHandler report.MouseHover, AddressOf Color_MouseHover
            AddHandler report.MouseLeave, AddressOf Color_MouseLeave
            AddHandler panel.Click, AddressOf Update_Click
            AddHandler panel.MouseHover, AddressOf Color_MouseHover
            AddHandler panel.MouseLeave, AddressOf Color_MouseLeave
            RepBox.Controls.Add(panel)
            ReportMap.Add(row.Field(Of Integer)("r_id"), panel)
        Next
        Return reports.Rows.Count
    End Function

    Private Sub ShowReport(ctl As Control)
        Seal_Init()

        Dim r_id = ctl.Tag
        Company_Info.Rows.Clear()
        Dim sql = "select u_name from reports r left join users u on r.u_id = u.u_id where r.r_id = ?"
        Dim table = Tools.GetData(conn, sql, r_id)
        Company_Info.Rows.Add("所属会社", employee.c_name)
        Company_Info.Rows.Add("所属部署", employee.d_name)
        Company_Info.Rows.Add("氏名", employee.e_name)
        Company_Info.Rows.Add("ユーザ名/プロジェクト名", table.Rows(0).Field(Of String)("u_name"))
        Company_Info.Rows(3).Height = 18
        Reports_Detail.Rows.Clear()
        sql = "select r_id,r_date,total_worktime,overtime,important_content,sales_flag,com_flag from reports where r_id = ?"
        table = Tools.GetData(conn, sql, r_id)
        If enableFlag Then
            If ctl.Controls.Count = 2 Then
                Reports_Detail.ReadOnly = True
                Commute.Enabled = False
                Submit_Button.Enabled = False
            Else
                Reports_Detail.ReadOnly = False
                Commute.Enabled = True
                Submit_Button.Enabled = True
            End If
        Else
            If ctl.Controls.Count = 2 Then
                Submit_Button.Text = "キャンセル"
            Else
                Submit_Button.Text = "承　認"
            End If
        End If

        Dim sales_flag = table.Rows(0).Field(Of Boolean)("sales_flag")
        Dim com_flag = table.Rows(0).Field(Of Boolean)("com_flag")
        If sales_flag Then
            Dim img = CType(Seal_Datagridview.Columns(1), DataGridViewImageColumn)
            img.Image = New Bitmap("..\..\Resources\" & employee.seal_local)
        ElseIf com_flag Then
            Dim img = CType(Seal_Datagridview.Columns(0), DataGridViewImageColumn)
            img.Image = New Bitmap("..\..\Resources\" & employee.seal_local)
        Else
            Dim img = CType(Seal_Datagridview.Columns(0), DataGridViewImageColumn)
            img.Image = seal
            img = CType(Seal_Datagridview.Columns(1), DataGridViewImageColumn)
            img.Image = seal
        End If

        Report_Date.Text = table.Rows(0).Field(Of String)("r_date")
        Report_Content.Text = table.Rows(0).Field(Of String)("important_content")

        Dim firstDay = CDate(table.Rows(0).Field(Of String)("r_date"))
        Dim days = Date.DaysInMonth(firstDay.Year, firstDay.Month)

        sql = "select start_time,end_time,work_time,work_content from reports_detail where r_id = ?"
        Dim table1 = Tools.GetData(conn, sql, r_id)
        For i = 0 To days - 1
            Dim week = Tools.GetWeekOfDay(firstDay.AddDays(i))
            Reports_Detail.Rows.Add((i + 1), week)
            Select Case week
                Case "(土)"
                    Reports_Detail.Rows(i).Cells(0).Style.ForeColor = Color.Blue
                    Reports_Detail.Rows(i).Cells(1).Style.ForeColor = Color.Blue
                Case "(日)"
                    Reports_Detail.Rows(i).Cells(0).Style.ForeColor = Color.Red
                    Reports_Detail.Rows(i).Cells(1).Style.ForeColor = Color.Red
            End Select
            If table.Rows.Count > 0 Then
                Dim row = table1.Rows(i)

                Dim start_time = row.Field(Of String)("start_time")
                Dim end_time = row.Field(Of String)("end_time")
                Dim work_time = row.Field(Of String)("work_time")
                Dim work_content = row.Field(Of String)("work_content")
                If start_time <> "" AndAlso end_time <> "" Then

                    Reports_Detail.Rows(i).SetValues((i + 1), week, CDate(start_time).ToShortTimeString, CDate(end_time).ToShortTimeString,
                                             work_time, work_content)
                Else
                    Reports_Detail.Rows(i).SetValues((i + 1), week, start_time, end_time,
                                             work_time, work_content)
                End If


            End If

        Next i
        Reports_Detail.Rows.Add(32 - days)
        Reports_Detail.Rows.Add("合計", Nothing, Nothing, Nothing, table.Rows(0).Field(Of String)("total_worktime"), Nothing)
    End Sub

    Private Sub Time_TextChange(sender As Object, e As EventArgs) Handles Reports_Detail.CellEndEdit
        Dim curRow = Reports_Detail.CurrentRow


        Try
            Dim value As String = Reports_Detail.CurrentCell.Value
            If value Is Nothing Then
                Throw New Exception
            End If

            If value.Length = 3 Then

                Dim hour As String = CInt(value.Substring(0, 1))
                Dim min As String = CInt(value.Substring(1, 2))

                min = Min_Change(min)

                If min = 60 Then
                    hour += min / 60
                    min = min Mod 60
                    If min = "0" Then
                        min = "00"
                    End If
                End If

                If hour > 24 Then
                    Throw New Exception
                End If

                Reports_Detail.CurrentCell.Value = hour & ":" & min

            ElseIf value.Length = 4 Then
                Dim hour = CInt(value.Substring(0, 2))
                Dim min = CInt(value.Substring(2, 2))

                If min = 60 Then
                    hour += min / 60
                    min = min Mod 60
                    If min = "0" Then
                        min = "00"
                    End If
                End If

                If hour > 24 Or (hour = 24 AndAlso min > 0) Then
                    Throw New Exception
                End If

                Reports_Detail.CurrentCell.Value = hour & ":" & min

            Else
                Throw New Exception
            End If
            If curRow.Cells(2).Value <> "" AndAlso curRow.Cells(3).Value <> "" Then
                WorkTime_Change()
            End If
            GetSumTime()
        Catch ex As Exception
            Reports_Detail.CurrentCell.Value = Nothing
            MessageBox.Show("「000」に参照して入力してください")
        End Try

    End Sub

    Private Sub WorkTime_Change()
        Dim curRow = Reports_Detail.CurrentRow
        Dim startTime As Date = CDate(curRow.Cells(2).Value)
        Dim endTime As Date = CDate(curRow.Cells(3).Value)

        If startTime > endTime Then
            endTime = endTime.AddDays(1)
        End If

        Dim time = (endTime - startTime).ToString.Substring(0, 5)
        If time.Substring(0, 1) = "0" Then
            time = time.Substring(1, 4)
        End If

        curRow.Cells(4).Value = time
    End Sub

    ''' <summary>
    ''' 総時間を取り出す
    ''' </summary>
    Private Sub GetSumTime()
        Dim sumHour = 0
        Dim sumMin = 0
        For i = 0 To 30
            Dim time = Split(Reports_Detail.Rows(i).Cells(4).Value, ":")
            If time.Length = 2 Then
                sumHour += CType(time(0), Integer)
                sumMin += CType(time(1), Integer)
            End If
        Next i

        sumHour += Int(sumMin / 60)
        sumMin = sumMin Mod 60
        Dim min = sumMin.ToString()
        If sumMin = 0 Then
            min = "00"
        End If
        Dim sumTime = sumHour & ":" & min

        Reports_Detail.Rows(32).Cells(4).Value = sumTime
    End Sub

    Private Function Min_Change(min As Integer) As String
        If min > 52 Then
            Return "60"
        ElseIf min <= 52 AndAlso min > 37 Then
            Return "45"
        ElseIf min <= 37 AndAlso min > 22 Then
            Return "30"
        ElseIf min <= 22 AndAlso min > 7 Then
            Return "15"
        Else
            Return "00"
        End If
    End Function

    '''<summary>
    ''' Reports表に対して更新する
    ''' </summary>
    ''' <param name="r_id"></param>
    Private Function UpdateReports(r_id As Integer) As Integer
        Dim sql = "update reports set total_worktime = ?,overtime = ?,important_content = ?,create_time = ? where r_id = ?"
        Dim total_worktime = Reports_Detail.Rows(32).Cells(4).Value
        Dim important_content = Report_Content.Text
        Dim now = Date.Now()
        Return Tools.SetData(conn, sql, total_worktime, total_worktime, important_content, now, r_id)
    End Function

    ''' <summary>
    ''' ReportsDetail表に対して更新する
    ''' </summary>
    ''' <param name="r_id"></param>
    Private Function UpdateReportsDetail(r_id As String) As Integer
        'Dim days = Getdays(year, mon)
        Dim sql = "select r_d_id from reports_detail where r_id = ?"
        Dim r_d_id = Tools.GetData(conn, sql, r_id)
        sql = "update reports_detail set start_time = ?,end_time = ?,work_time = ?,work_content = ? where r_d_id = ?"
        Dim sum = 0
        For i = 0 To r_d_id.Rows.Count - 1
            Dim startTime = Reports_Detail.Rows(i).Cells(2).Value
            Dim endTime = Reports_Detail.Rows(i).Cells(3).Value
            Dim workTime = Reports_Detail.Rows(i).Cells(4).Value
            Dim workContent = Reports_Detail.Rows(i).Cells(5).Value
            Dim rdId = r_d_id.Rows(i).Field(Of Integer)("r_d_id")
            sum += Tools.SetData(conn, sql, startTime, endTime, workTime, workContent, rdId)
        Next
        Console.WriteLine("実行行目：" & sum)
        Return sum
    End Function

    ''' <summary>
    ''' メッセージを登録する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles Submit_Button.Click, Excel_Button.Click
        Dim r_id = TableLayoutPanel1.Tag
        Select Case CType(sender, Control).Text
            Case "保　存"
                Dim num = UpdateReports(r_id)
                Dim num1 = UpdateReportsDetail(r_id)
                MessageBox.Show("Reports表の中の影響される行目：" & num & vbLf &
                            "ReportsDetail表の中の影響される行目：" & num1)
            Case "承　認"
                Select Case employee.d_id
                    Case 1, 2, 4, 5, 7, 8
                        Dim sql = "update reports set com_flag = 1 where r_id = ?"
                        Console.WriteLine(Tools.SetData(conn, sql, r_id))
                    Case 3, 6, 9
                        Dim sql = "update reports set sales_flag = 1 where r_id = ?"
                        Console.WriteLine(Tools.SetData(conn, sql, r_id))
                End Select
                ConRepBox_Init()
                Update_Click(ReportMap(TableLayoutPanel1.Tag), e)
            Case "キャンセル"
                Dim sql = "update reports set com_flag = 0,sales_flag = 0 where r_id = ?"
                Console.WriteLine(Tools.SetData(conn, sql, r_id))
                ConRepBox_Init()

                Update_Click(ReportMap(TableLayoutPanel1.Tag), e)


        End Select
    End Sub


    Private appXL As Excel.Application
    Private wbXl As Excel.Workbook
    Private shXL As Excel.Worksheet

    ''' <summary>
    ''' EXCEL作成ボタンを押すと作成報告書をexcelに出力します
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Excel_Button_Click(sender As Object, e As EventArgs) Handles Excel_Button.Click
        Dim r_date = Report_Date.Text
        appXL = New Excel.Application With {
            .DisplayAlerts = True,
            .ScreenUpdating = False,
            .EnableEvents = False
            }

        'File.Copy("..\..\Excel\Sample.xls", saveFile, True)
        'If File.Exists(saveFile) Then
        '    File.Create(saveFile)
        'End If
        'File.Copy("..\..\Excel\Sample.xlsx", "C:\Users\zzq\Desktop\Sample.xlsx")
        Dim path = IO.Path.GetDirectoryName(IO.Path.GetDirectoryName(IO.Directory.GetCurrentDirectory())) & "\Excel\Sample.xls"
        wbXl = appXL.Workbooks.Open(path)
        shXL = wbXl.Sheets(1)   '第Ｎのtable sheetを取り出す
        '報告書の年月日
        shXL.Cells(4, 8) = r_date
        '会社情報
        shXL.Cells(6, 6) = Company_Info(1, 0).Value
        '部門情報
        shXL.Cells(7, 6) = Company_Info(1, 1).Value
        '個人情報
        shXL.Cells(8, 6) = Company_Info(1, 2).Value
        'ユーザー情報
        shXL.Cells(9, 6) = Company_Info(1, 3).Value

        'shXL.Range("C17:D47").Font.Color = Color.Black
        'Dim dates = GetDates.GetDate(Date_ComboBox.Text)
        'shXL.Range("C17:D47").Value = dates
        Insert_Reports_Detail_Excel()
        appXL.ScreenUpdating = True
        appXL.EnableEvents = True
        appXL.Visible = True
        '報告書を保存します
        Dim dateArr = Report_Date.Text.Split("/")
        Dim saveFile = System.Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\" & dateArr(0) & dateArr(1) & "_" & Company_Info(1, 2).Value & ".xls"
        wbXl.SaveAs(saveFile)
        'EXCELが閉じる
        wbXl.Close(False, Type.Missing, Type.Missing)
        appXL.Workbooks.Close()
        appXL.Quit()
        System.Runtime.InteropServices.Marshal.ReleaseComObject(appXL)
        System.Runtime.InteropServices.Marshal.ReleaseComObject(shXL)
        System.Runtime.InteropServices.Marshal.ReleaseComObject(wbXl)
        wbXl = Nothing
        appXL = Nothing
        shXL = Nothing
        GC.Collect()
        GC.WaitForPendingFinalizers()

    End Sub

    ''' <summary>
    ''' 報告詳細がEXCELに入力します
    ''' </summary>
    Private Sub Insert_Reports_Detail_Excel()
        Dim rows As Integer = 17
        For i = 0 To 30
            '日付
            shXL.Cells(rows, 3) = Reports_Detail(0, i).Value
            '曜日
            Dim week = Reports_Detail(1, i).Value
            shXL.Cells(rows, 4) = week
            '文字列のカラーを設定する
            Select Case week
                Case "(日)"
                    CType(shXL.Cells(rows, 3), Excel.Range).Font.Color = Color.Red
                    CType(shXL.Cells(rows, 4), Excel.Range).Font.Color = Color.Red
                Case "(土)"
                    CType(shXL.Cells(rows, 3), Excel.Range).Font.Color = Color.Blue
                    CType(shXL.Cells(rows, 4), Excel.Range).Font.Color = Color.Blue

            End Select
            '開始時間
            shXL.Cells(rows, 5) = Reports_Detail(2, i).Value
            '終了時間
            shXL.Cells(rows, 6) = Reports_Detail(3, i).Value
            '工数
            shXL.Cells(rows, 7) = Reports_Detail(4, i).Value
            '作業内容
            shXL.Cells(rows, 8) = Reports_Detail(5, i).Value
            rows += 1
        Next
        '勤務時間の合計
        shXL.Cells(49, 7) = Reports_Detail(4, 32).Value
        '重要事項
        shXL.Cells(51, 3) = Report_Content.Text

    End Sub

    Private Sub FucLabel_Click(sender As Object, e As EventArgs) Handles FucLabel.Click

    End Sub

    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub
End Class
