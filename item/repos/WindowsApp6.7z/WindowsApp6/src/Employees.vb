﻿Public Class Employees
    Public e_name As String
    Public c_name As String
    Public d_name As String
    Public u_name As String
    Public total_worktime As String
    Public days As Integer
    Public reportList As List(Of Reports)
    Public important_content As String
End Class
