﻿Public Class Reports
    Public day As String
    Public week As String
    Public start_time As DateTime
    Public end_time As DateTime
    Public work_time As String
    Public work_content As String
End Class
