﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.SealView = New System.Windows.Forms.DataGridView()
        Me.dep_manager = New System.Windows.Forms.DataGridViewImageColumn()
        Me.off_manager = New System.Windows.Forms.DataGridViewImageColumn()
        Me.pro_manager = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.WorkTable = New System.Windows.Forms.Label()
        Me.MessageView = New System.Windows.Forms.DataGridView()
        Me.Message = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MessageValue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tittle = New System.Windows.Forms.Label()
        Me.Year = New System.Windows.Forms.TextBox()
        Me.Mon = New System.Windows.Forms.TextBox()
        Me.ReportView = New System.Windows.Forms.DataGridView()
        Me.WorkTittle = New System.Windows.Forms.Label()
        Me.WorkText = New System.Windows.Forms.TextBox()
        CType(Me.SealView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MessageView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReportView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SealView
        '
        Me.SealView.AllowUserToAddRows = False
        Me.SealView.AllowUserToOrderColumns = True
        Me.SealView.AllowUserToResizeColumns = False
        Me.SealView.AllowUserToResizeRows = False
        Me.SealView.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 7.8!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SealView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.SealView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SealView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dep_manager, Me.off_manager, Me.pro_manager})
        Me.SealView.Location = New System.Drawing.Point(393, 139)
        Me.SealView.Name = "SealView"
        Me.SealView.ReadOnly = True
        Me.SealView.RowHeadersVisible = False
        Me.SealView.RowHeadersWidth = 51
        Me.SealView.RowTemplate.Height = 21
        Me.SealView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SealView.Size = New System.Drawing.Size(243, 113)
        Me.SealView.TabIndex = 24
        '
        'dep_manager
        '
        Me.dep_manager.HeaderText = "部長"
        Me.dep_manager.Image = Global.Report.My.Resources.Resources.tyou
        Me.dep_manager.MinimumWidth = 6
        Me.dep_manager.Name = "dep_manager"
        Me.dep_manager.ReadOnly = True
        Me.dep_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dep_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.dep_manager.Width = 80
        '
        'off_manager
        '
        Me.off_manager.HeaderText = "課長"
        Me.off_manager.Image = Global.Report.My.Resources.Resources.tyou
        Me.off_manager.MinimumWidth = 6
        Me.off_manager.Name = "off_manager"
        Me.off_manager.ReadOnly = True
        Me.off_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.off_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.off_manager.Width = 80
        '
        'pro_manager
        '
        Me.pro_manager.HeaderText = "プロジェクト管理者"
        Me.pro_manager.Image = Global.Report.My.Resources.Resources.tyou
        Me.pro_manager.MinimumWidth = 6
        Me.pro_manager.Name = "pro_manager"
        Me.pro_manager.ReadOnly = True
        Me.pro_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.pro_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.pro_manager.Width = 80
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(53, 39)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 12)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "（標準版）"
        '
        'WorkTable
        '
        Me.WorkTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.WorkTable.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.75!)
        Me.WorkTable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.WorkTable.Location = New System.Drawing.Point(113, 258)
        Me.WorkTable.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.WorkTable.Name = "WorkTable"
        Me.WorkTable.Size = New System.Drawing.Size(80, 18)
        Me.WorkTable.TabIndex = 22
        Me.WorkTable.Text = "作業報告欄"
        Me.WorkTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MessageView
        '
        Me.MessageView.AllowUserToAddRows = False
        Me.MessageView.AllowUserToResizeColumns = False
        Me.MessageView.AllowUserToResizeRows = False
        Me.MessageView.BackgroundColor = System.Drawing.SystemColors.Window
        Me.MessageView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MessageView.ColumnHeadersVisible = False
        Me.MessageView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Message, Me.MessageValue})
        Me.MessageView.Location = New System.Drawing.Point(55, 142)
        Me.MessageView.Margin = New System.Windows.Forms.Padding(2)
        Me.MessageView.Name = "MessageView"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MessageView.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.MessageView.RowHeadersVisible = False
        Me.MessageView.RowHeadersWidth = 51
        Me.MessageView.RowTemplate.Height = 27
        Me.MessageView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.MessageView.Size = New System.Drawing.Size(278, 108)
        Me.MessageView.TabIndex = 21
        '
        'Message
        '
        Me.Message.HeaderText = "Message"
        Me.Message.MinimumWidth = 6
        Me.Message.Name = "Message"
        Me.Message.ReadOnly = True
        Me.Message.Width = 138
        '
        'MessageValue
        '
        Me.MessageValue.HeaderText = "MessageList"
        Me.MessageValue.MinimumWidth = 6
        Me.MessageValue.Name = "MessageValue"
        Me.MessageValue.ReadOnly = True
        Me.MessageValue.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.MessageValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.MessageValue.Width = 137
        '
        'Tittle
        '
        Me.Tittle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tittle.Font = New System.Drawing.Font("SimSun-ExtB", 20.0!)
        Me.Tittle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Tittle.Location = New System.Drawing.Point(271, 39)
        Me.Tittle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Tittle.Name = "Tittle"
        Me.Tittle.Size = New System.Drawing.Size(162, 32)
        Me.Tittle.TabIndex = 20
        Me.Tittle.Text = "作業報告書"
        Me.Tittle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Year
        '
        Me.Year.Location = New System.Drawing.Point(271, 93)
        Me.Year.Name = "Year"
        Me.Year.Size = New System.Drawing.Size(76, 19)
        Me.Year.TabIndex = 25
        '
        'Mon
        '
        Me.Mon.Location = New System.Drawing.Point(354, 92)
        Me.Mon.Name = "Mon"
        Me.Mon.Size = New System.Drawing.Size(79, 19)
        Me.Mon.TabIndex = 26
        '
        'ReportView
        '
        Me.ReportView.BackgroundColor = System.Drawing.SystemColors.Window
        Me.ReportView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ReportView.Location = New System.Drawing.Point(55, 285)
        Me.ReportView.Name = "ReportView"
        Me.ReportView.RowTemplate.Height = 21
        Me.ReportView.Size = New System.Drawing.Size(581, 603)
        Me.ReportView.TabIndex = 27
        '
        'WorkTittle
        '
        Me.WorkTittle.AutoSize = True
        Me.WorkTittle.Font = New System.Drawing.Font("SimSun-ExtB", 12.0!)
        Me.WorkTittle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.WorkTittle.Location = New System.Drawing.Point(52, 892)
        Me.WorkTittle.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.WorkTittle.Name = "WorkTittle"
        Me.WorkTittle.Size = New System.Drawing.Size(96, 16)
        Me.WorkTittle.TabIndex = 29
        Me.WorkTittle.Text = "[特記事項］"
        '
        'WorkText
        '
        Me.WorkText.Location = New System.Drawing.Point(55, 910)
        Me.WorkText.Margin = New System.Windows.Forms.Padding(2)
        Me.WorkText.Multiline = True
        Me.WorkText.Name = "WorkText"
        Me.WorkText.Size = New System.Drawing.Size(581, 106)
        Me.WorkText.TabIndex = 28
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(707, 881)
        Me.Controls.Add(Me.WorkTittle)
        Me.Controls.Add(Me.WorkText)
        Me.Controls.Add(Me.ReportView)
        Me.Controls.Add(Me.Mon)
        Me.Controls.Add(Me.Year)
        Me.Controls.Add(Me.SealView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.WorkTable)
        Me.Controls.Add(Me.MessageView)
        Me.Controls.Add(Me.Tittle)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.SealView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MessageView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReportView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SealView As DataGridView
    Friend WithEvents dep_manager As DataGridViewImageColumn
    Friend WithEvents off_manager As DataGridViewImageColumn
    Friend WithEvents pro_manager As DataGridViewImageColumn
    Friend WithEvents Label2 As Label
    Friend WithEvents WorkTable As Label
    Friend WithEvents MessageView As DataGridView
    Friend WithEvents Message As DataGridViewTextBoxColumn
    Friend WithEvents MessageValue As DataGridViewTextBoxColumn
    Friend WithEvents Tittle As Label
    Friend WithEvents Year As TextBox
    Friend WithEvents Mon As TextBox
    Friend WithEvents ReportView As DataGridView
    Friend WithEvents WorkTittle As Label
    Friend WithEvents WorkText As TextBox
End Class
