﻿Public Module Uitl
    Enum Position
        com_manager = 1
        depart_manager = 2
        off_manager = 3
        group_manager = 4
        emp = 5
    End Enum
End Module
