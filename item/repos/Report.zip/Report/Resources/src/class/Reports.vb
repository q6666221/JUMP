﻿Public Class Reports
    Public day As String
    Public week As String
    Public start_time As DateTime
    Public end_time As DateTime
    Public work_time As TimeSpan
    Public work_content As String

    Public Sub SetTime(start_time As DateTime, end_time As DateTime)
        Me.start_time = end_time
        Me.end_time = end_time
        Me.work_time = end_time - start_time
    End Sub
End Class
