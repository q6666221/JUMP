﻿Public Class Employees
    Public e_name As String
    Public e_id As String
    Public c_name As String
    Public c_id As String
    Public d_name As String
    Public d_id As String
    Public m_id As String
    Public p_id As String
    Public u_name As String
    Public u_id As String
    Public r_id As String
    Public seal_local As String
    Public total_worktime As TimeSpan
    Public overtime As Single
    Public important_content As String

End Class
