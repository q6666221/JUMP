﻿Public Class Form1
    Private Sub MessageViewInit()
        MessageView.Rows.Add("所属会社", Me.employee.c_name)
        MessageView.Rows.Add("所属部署", Me.employee.d_name)
        MessageView.Rows.Add("氏名", Me.employee.e_name)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MessageViewInit()
        PermissionViewInit()
    End Sub

    Private Sub PermissionViewInit()
        PermissionView.Rows.Add("reportを入力")
        If employee.p_id <> Uitl.Position.emp Then
            PermissionView.Rows.Add("reportを確認")
        End If
    End Sub

    Private Sub PermissionView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles PermissionView.CellContentClick
        Select Case PermissionView.CurrentRow.Index
            Case 0
                Report_Input()
            Case 1
                Report_Output()
        End Select

    End Sub

    Private Sub Report_Input()
        Dim report As New Form2(Me.employee, conn)
        report.ShowDialog()
    End Sub

    Private Sub Report_Output()

    End Sub
End Class