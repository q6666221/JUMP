﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Home
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuBox = New System.Windows.Forms.Panel()
        Me.Manage = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Confirm = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Product = New System.Windows.Forms.Button()
        Me.NameText = New System.Windows.Forms.TextBox()
        Me.MarginBottonBox = New System.Windows.Forms.Panel()
        Me.MarginTopBox = New System.Windows.Forms.Panel()
        Me.RepBox = New System.Windows.Forms.Panel()
        Me.TittleBox = New System.Windows.Forms.Panel()
        Me.ReportTittle = New System.Windows.Forms.Label()
        Me.CtlBox = New System.Windows.Forms.Panel()
        Me.MinButton = New System.Windows.Forms.Button()
        Me.MaxButton = New System.Windows.Forms.Button()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.FucBox = New System.Windows.Forms.Panel()
        Me.Insert = New System.Windows.Forms.Button()
        Me.ManageTittle = New System.Windows.Forms.Panel()
        Me.ManagerLabel = New System.Windows.Forms.Label()
        Me.ProTittleBox = New System.Windows.Forms.Panel()
        Me.FucLabel = New System.Windows.Forms.Label()
        Me.ConTittleBox = New System.Windows.Forms.Panel()
        Me.FinishStateLabel = New System.Windows.Forms.Label()
        Me.ReportDetailBox = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Report_Content = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Reports_Detail = New System.Windows.Forms.DataGridView()
        Me.dates = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.weeks = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.start_time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.end_time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.worktime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.reports_content = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Submit_Button = New System.Windows.Forms.Button()
        Me.Company_Info = New System.Windows.Forms.DataGridView()
        Me.com_info = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.com_select = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Seal_Datagridview = New System.Windows.Forms.DataGridView()
        Me.minister = New System.Windows.Forms.DataGridViewImageColumn()
        Me.supervisor = New System.Windows.Forms.DataGridViewImageColumn()
        Me.project_administrator = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.reports = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Report_Date = New System.Windows.Forms.TextBox()
        Me.Commute = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Excel_Button = New System.Windows.Forms.Button()
        Me.Calendar_Panel = New System.Windows.Forms.TableLayoutPanel()
        Me.Calendar_View = New System.Windows.Forms.DataGridView()
        Me.Sunday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Monday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tuesday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Wednesday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Thursday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Friday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Saturday = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RestTime_Panel = New System.Windows.Forms.TableLayoutPanel()
        Me.Dinner_Label = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Lunch_Label = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Site_ComboBox = New System.Windows.Forms.ComboBox()
        Me.Rest_Button = New System.Windows.Forms.Button()
        Me.Dinner_StartTime = New System.Windows.Forms.ComboBox()
        Me.Dinner_EndTime = New System.Windows.Forms.ComboBox()
        Me.Lunch_StartTime = New System.Windows.Forms.ComboBox()
        Me.Lunch_EndTime = New System.Windows.Forms.ComboBox()
        Me.MenuBox.SuspendLayout()
        Me.TittleBox.SuspendLayout()
        Me.CtlBox.SuspendLayout()
        Me.FucBox.SuspendLayout()
        Me.ManageTittle.SuspendLayout()
        Me.ProTittleBox.SuspendLayout()
        Me.ConTittleBox.SuspendLayout()
        Me.ReportDetailBox.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel13.SuspendLayout()
        CType(Me.Reports_Detail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Company_Info, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Seal_Datagridview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Calendar_Panel.SuspendLayout()
        CType(Me.Calendar_View, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RestTime_Panel.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuBox
        '
        Me.MenuBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.MenuBox.Controls.Add(Me.Manage)
        Me.MenuBox.Controls.Add(Me.Panel2)
        Me.MenuBox.Controls.Add(Me.Confirm)
        Me.MenuBox.Controls.Add(Me.Panel1)
        Me.MenuBox.Controls.Add(Me.Product)
        Me.MenuBox.Controls.Add(Me.NameText)
        Me.MenuBox.Controls.Add(Me.MarginBottonBox)
        Me.MenuBox.Controls.Add(Me.MarginTopBox)
        Me.MenuBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuBox.Location = New System.Drawing.Point(0, 0)
        Me.MenuBox.Margin = New System.Windows.Forms.Padding(2)
        Me.MenuBox.Name = "MenuBox"
        Me.MenuBox.Size = New System.Drawing.Size(52, 640)
        Me.MenuBox.TabIndex = 0
        '
        'Manage
        '
        Me.Manage.Dock = System.Windows.Forms.DockStyle.Top
        Me.Manage.FlatAppearance.BorderSize = 0
        Me.Manage.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Manage.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.Manage.Location = New System.Drawing.Point(0, 121)
        Me.Manage.Name = "Manage"
        Me.Manage.Size = New System.Drawing.Size(52, 28)
        Me.Manage.TabIndex = 6
        Me.Manage.Text = "管理"
        Me.Manage.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 111)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(52, 10)
        Me.Panel2.TabIndex = 7
        '
        'Confirm
        '
        Me.Confirm.Dock = System.Windows.Forms.DockStyle.Top
        Me.Confirm.FlatAppearance.BorderSize = 0
        Me.Confirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Confirm.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.Confirm.Location = New System.Drawing.Point(0, 83)
        Me.Confirm.Name = "Confirm"
        Me.Confirm.Size = New System.Drawing.Size(52, 28)
        Me.Confirm.TabIndex = 4
        Me.Confirm.Text = "承認"
        Me.Confirm.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 73)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(52, 10)
        Me.Panel1.TabIndex = 0
        '
        'Product
        '
        Me.Product.Dock = System.Windows.Forms.DockStyle.Top
        Me.Product.FlatAppearance.BorderSize = 0
        Me.Product.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Product.ForeColor = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.Product.Location = New System.Drawing.Point(0, 45)
        Me.Product.Name = "Product"
        Me.Product.Size = New System.Drawing.Size(52, 28)
        Me.Product.TabIndex = 3
        Me.Product.Text = "作成"
        Me.Product.UseVisualStyleBackColor = True
        '
        'NameText
        '
        Me.NameText.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(46, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.NameText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.NameText.Dock = System.Windows.Forms.DockStyle.Top
        Me.NameText.Enabled = False
        Me.NameText.Font = New System.Drawing.Font("MS UI Gothic", 8.0!)
        Me.NameText.ForeColor = System.Drawing.SystemColors.Window
        Me.NameText.Location = New System.Drawing.Point(0, 20)
        Me.NameText.Multiline = True
        Me.NameText.Name = "NameText"
        Me.NameText.Size = New System.Drawing.Size(52, 25)
        Me.NameText.TabIndex = 5
        Me.NameText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'MarginBottonBox
        '
        Me.MarginBottonBox.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MarginBottonBox.Location = New System.Drawing.Point(0, 636)
        Me.MarginBottonBox.Name = "MarginBottonBox"
        Me.MarginBottonBox.Size = New System.Drawing.Size(52, 4)
        Me.MarginBottonBox.TabIndex = 2
        '
        'MarginTopBox
        '
        Me.MarginTopBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.MarginTopBox.Location = New System.Drawing.Point(0, 0)
        Me.MarginTopBox.Name = "MarginTopBox"
        Me.MarginTopBox.Size = New System.Drawing.Size(52, 20)
        Me.MarginTopBox.TabIndex = 2
        '
        'RepBox
        '
        Me.RepBox.AutoScroll = True
        Me.RepBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(189, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(191, Byte), Integer))
        Me.RepBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.RepBox.Location = New System.Drawing.Point(52, 60)
        Me.RepBox.Margin = New System.Windows.Forms.Padding(2)
        Me.RepBox.Name = "RepBox"
        Me.RepBox.Size = New System.Drawing.Size(164, 580)
        Me.RepBox.TabIndex = 1
        '
        'TittleBox
        '
        Me.TittleBox.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TittleBox.Controls.Add(Me.ReportTittle)
        Me.TittleBox.Controls.Add(Me.CtlBox)
        Me.TittleBox.Controls.Add(Me.FucBox)
        Me.TittleBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.TittleBox.Location = New System.Drawing.Point(52, 0)
        Me.TittleBox.Margin = New System.Windows.Forms.Padding(2)
        Me.TittleBox.Name = "TittleBox"
        Me.TittleBox.Size = New System.Drawing.Size(1016, 60)
        Me.TittleBox.TabIndex = 2
        '
        'ReportTittle
        '
        Me.ReportTittle.AutoSize = True
        Me.ReportTittle.Location = New System.Drawing.Point(179, 36)
        Me.ReportTittle.Name = "ReportTittle"
        Me.ReportTittle.Size = New System.Drawing.Size(0, 12)
        Me.ReportTittle.TabIndex = 4
        '
        'CtlBox
        '
        Me.CtlBox.Controls.Add(Me.MinButton)
        Me.CtlBox.Controls.Add(Me.MaxButton)
        Me.CtlBox.Controls.Add(Me.CloseButton)
        Me.CtlBox.Dock = System.Windows.Forms.DockStyle.Top
        Me.CtlBox.Location = New System.Drawing.Point(164, 0)
        Me.CtlBox.Margin = New System.Windows.Forms.Padding(2)
        Me.CtlBox.Name = "CtlBox"
        Me.CtlBox.Size = New System.Drawing.Size(852, 25)
        Me.CtlBox.TabIndex = 3
        '
        'MinButton
        '
        Me.MinButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.MinButton.FlatAppearance.BorderSize = 0
        Me.MinButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MinButton.Location = New System.Drawing.Point(750, 0)
        Me.MinButton.Margin = New System.Windows.Forms.Padding(2)
        Me.MinButton.Name = "MinButton"
        Me.MinButton.Size = New System.Drawing.Size(34, 25)
        Me.MinButton.TabIndex = 2
        Me.MinButton.Text = "Min"
        Me.MinButton.UseVisualStyleBackColor = True
        '
        'MaxButton
        '
        Me.MaxButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.MaxButton.FlatAppearance.BorderSize = 0
        Me.MaxButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MaxButton.Location = New System.Drawing.Point(784, 0)
        Me.MaxButton.Margin = New System.Windows.Forms.Padding(2)
        Me.MaxButton.Name = "MaxButton"
        Me.MaxButton.Size = New System.Drawing.Size(34, 25)
        Me.MaxButton.TabIndex = 1
        Me.MaxButton.Text = "Max"
        Me.MaxButton.UseVisualStyleBackColor = True
        '
        'CloseButton
        '
        Me.CloseButton.Dock = System.Windows.Forms.DockStyle.Right
        Me.CloseButton.FlatAppearance.BorderSize = 0
        Me.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CloseButton.Location = New System.Drawing.Point(818, 0)
        Me.CloseButton.Margin = New System.Windows.Forms.Padding(2)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(34, 25)
        Me.CloseButton.TabIndex = 0
        Me.CloseButton.Text = "Clo"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'FucBox
        '
        Me.FucBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.FucBox.Controls.Add(Me.Insert)
        Me.FucBox.Controls.Add(Me.ManageTittle)
        Me.FucBox.Controls.Add(Me.ProTittleBox)
        Me.FucBox.Controls.Add(Me.ConTittleBox)
        Me.FucBox.Dock = System.Windows.Forms.DockStyle.Left
        Me.FucBox.Location = New System.Drawing.Point(0, 0)
        Me.FucBox.Margin = New System.Windows.Forms.Padding(2)
        Me.FucBox.Name = "FucBox"
        Me.FucBox.Size = New System.Drawing.Size(164, 60)
        Me.FucBox.TabIndex = 1
        '
        'Insert
        '
        Me.Insert.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.Insert.FlatAppearance.BorderSize = 0
        Me.Insert.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Insert.Location = New System.Drawing.Point(0, 25)
        Me.Insert.Name = "Insert"
        Me.Insert.Size = New System.Drawing.Size(164, 35)
        Me.Insert.TabIndex = 1
        Me.Insert.Text = "追加"
        Me.Insert.UseVisualStyleBackColor = False
        '
        'ManageTittle
        '
        Me.ManageTittle.Controls.Add(Me.ManagerLabel)
        Me.ManageTittle.Location = New System.Drawing.Point(0, 0)
        Me.ManageTittle.Name = "ManageTittle"
        Me.ManageTittle.Size = New System.Drawing.Size(164, 25)
        Me.ManageTittle.TabIndex = 0
        '
        'ManagerLabel
        '
        Me.ManagerLabel.AutoSize = True
        Me.ManagerLabel.Location = New System.Drawing.Point(3, 5)
        Me.ManagerLabel.Name = "ManagerLabel"
        Me.ManagerLabel.Size = New System.Drawing.Size(35, 12)
        Me.ManagerLabel.TabIndex = 0
        Me.ManagerLabel.Text = "管理："
        '
        'ProTittleBox
        '
        Me.ProTittleBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.ProTittleBox.Controls.Add(Me.FucLabel)
        Me.ProTittleBox.Location = New System.Drawing.Point(0, 0)
        Me.ProTittleBox.Name = "ProTittleBox"
        Me.ProTittleBox.Size = New System.Drawing.Size(164, 25)
        Me.ProTittleBox.TabIndex = 3
        '
        'FucLabel
        '
        Me.FucLabel.AutoSize = True
        Me.FucLabel.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.0!)
        Me.FucLabel.Location = New System.Drawing.Point(3, 5)
        Me.FucLabel.Name = "FucLabel"
        Me.FucLabel.Size = New System.Drawing.Size(105, 14)
        Me.FucLabel.TabIndex = 0
        Me.FucLabel.Text = "作業報告作成："
        '
        'ConTittleBox
        '
        Me.ConTittleBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(222, Byte), Integer), CType(CType(222, Byte), Integer))
        Me.ConTittleBox.Controls.Add(Me.FinishStateLabel)
        Me.ConTittleBox.Location = New System.Drawing.Point(0, 0)
        Me.ConTittleBox.Name = "ConTittleBox"
        Me.ConTittleBox.Size = New System.Drawing.Size(164, 25)
        Me.ConTittleBox.TabIndex = 0
        '
        'FinishStateLabel
        '
        Me.FinishStateLabel.AutoSize = True
        Me.FinishStateLabel.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.0!)
        Me.FinishStateLabel.Location = New System.Drawing.Point(3, 5)
        Me.FinishStateLabel.Name = "FinishStateLabel"
        Me.FinishStateLabel.Size = New System.Drawing.Size(105, 14)
        Me.FinishStateLabel.TabIndex = 0
        Me.FinishStateLabel.Text = "作業報告承認："
        '
        'ReportDetailBox
        '
        Me.ReportDetailBox.AutoScroll = True
        Me.ReportDetailBox.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ReportDetailBox.Controls.Add(Me.TableLayoutPanel1)
        Me.ReportDetailBox.Controls.Add(Me.Calendar_Panel)
        Me.ReportDetailBox.Controls.Add(Me.RestTime_Panel)
        Me.ReportDetailBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReportDetailBox.Location = New System.Drawing.Point(216, 60)
        Me.ReportDetailBox.Margin = New System.Windows.Forms.Padding(2)
        Me.ReportDetailBox.Name = "ReportDetailBox"
        Me.ReportDetailBox.Size = New System.Drawing.Size(852, 580)
        Me.ReportDetailBox.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 14
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 41.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 38.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 64.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 94.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 17.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label2, 11, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label6, 4, 11)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel13, 2, 13)
        Me.TableLayoutPanel1.Controls.Add(Me.Submit_Button, 12, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Company_Info, 2, 5)
        Me.TableLayoutPanel1.Controls.Add(Me.Label1, 10, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Seal_Datagridview, 10, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label4, 10, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.reports, 6, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label3, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Report_Date, 7, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Commute, 8, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Label5, 7, 12)
        Me.TableLayoutPanel1.Controls.Add(Me.Excel_Button, 10, 12)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 64
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 18.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(764, 1083)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'Label2
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label2, 2)
        Me.Label2.Location = New System.Drawing.Point(563, 0)
        Me.Label2.Margin = New System.Windows.Forms.Padding(0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(184, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Rev 2016/04/01"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label6, 2)
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Location = New System.Drawing.Point(109, 226)
        Me.Label6.Margin = New System.Windows.Forms.Padding(0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 18)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "作　業　報　告　欄"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel13
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Panel13, 11)
        Me.Panel13.Controls.Add(Me.Report_Content)
        Me.Panel13.Controls.Add(Me.Label7)
        Me.Panel13.Controls.Add(Me.Reports_Detail)
        Me.Panel13.Location = New System.Drawing.Point(30, 266)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel13.Name = "Panel13"
        Me.TableLayoutPanel1.SetRowSpan(Me.Panel13, 44)
        Me.Panel13.Size = New System.Drawing.Size(716, 774)
        Me.Panel13.TabIndex = 14
        '
        'Report_Content
        '
        Me.Report_Content.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Report_Content.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Report_Content.Location = New System.Drawing.Point(0, 627)
        Me.Report_Content.Margin = New System.Windows.Forms.Padding(0)
        Me.Report_Content.Multiline = True
        Me.Report_Content.Name = "Report_Content"
        Me.Report_Content.Size = New System.Drawing.Size(716, 147)
        Me.Report_Content.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(0, 609)
        Me.Label7.Margin = New System.Windows.Forms.Padding(0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 18)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "[特記事項］"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Reports_Detail
        '
        Me.Reports_Detail.AllowUserToAddRows = False
        Me.Reports_Detail.AllowUserToDeleteRows = False
        Me.Reports_Detail.AllowUserToResizeColumns = False
        Me.Reports_Detail.AllowUserToResizeRows = False
        Me.Reports_Detail.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.Reports_Detail.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Reports_Detail.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Reports_Detail.ColumnHeadersHeight = 44
        Me.Reports_Detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Reports_Detail.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dates, Me.weeks, Me.start_time, Me.end_time, Me.worktime, Me.reports_content})
        Me.Reports_Detail.Location = New System.Drawing.Point(0, 0)
        Me.Reports_Detail.Margin = New System.Windows.Forms.Padding(0)
        Me.Reports_Detail.Name = "Reports_Detail"
        Me.Reports_Detail.RowHeadersVisible = False
        Me.Reports_Detail.RowHeadersWidth = 51
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Reports_Detail.RowsDefaultCellStyle = DataGridViewCellStyle7
        Me.Reports_Detail.RowTemplate.Height = 17
        Me.Reports_Detail.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Reports_Detail.Size = New System.Drawing.Size(716, 605)
        Me.Reports_Detail.TabIndex = 13
        '
        'dates
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.dates.DefaultCellStyle = DataGridViewCellStyle2
        Me.dates.Frozen = True
        Me.dates.HeaderText = "日付"
        Me.dates.MinimumWidth = 6
        Me.dates.Name = "dates"
        Me.dates.ReadOnly = True
        Me.dates.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dates.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.dates.Width = 40
        '
        'weeks
        '
        Me.weeks.HeaderText = "曜日"
        Me.weeks.MinimumWidth = 6
        Me.weeks.Name = "weeks"
        Me.weeks.ReadOnly = True
        Me.weeks.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.weeks.Width = 40
        '
        'start_time
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.start_time.DefaultCellStyle = DataGridViewCellStyle3
        Me.start_time.HeaderText = "開始"
        Me.start_time.MinimumWidth = 6
        Me.start_time.Name = "start_time"
        Me.start_time.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.start_time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.start_time.Width = 63
        '
        'end_time
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.end_time.DefaultCellStyle = DataGridViewCellStyle4
        Me.end_time.HeaderText = "終了"
        Me.end_time.MinimumWidth = 6
        Me.end_time.Name = "end_time"
        Me.end_time.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.end_time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.end_time.Width = 63
        '
        'worktime
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.worktime.DefaultCellStyle = DataGridViewCellStyle5
        Me.worktime.HeaderText = "工数"
        Me.worktime.MinimumWidth = 6
        Me.worktime.Name = "worktime"
        Me.worktime.ReadOnly = True
        Me.worktime.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.worktime.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.worktime.Width = 63
        '
        'reports_content
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.reports_content.DefaultCellStyle = DataGridViewCellStyle6
        Me.reports_content.HeaderText = "作業内容"
        Me.reports_content.MinimumWidth = 6
        Me.reports_content.Name = "reports_content"
        Me.reports_content.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.reports_content.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.reports_content.Width = 445
        '
        'Submit_Button
        '
        Me.Submit_Button.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Submit_Button.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Submit_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Submit_Button.Location = New System.Drawing.Point(653, 244)
        Me.Submit_Button.Margin = New System.Windows.Forms.Padding(0)
        Me.Submit_Button.Name = "Submit_Button"
        Me.Submit_Button.Size = New System.Drawing.Size(94, 22)
        Me.Submit_Button.TabIndex = 15
        Me.Submit_Button.Text = "保　存"
        Me.Submit_Button.UseVisualStyleBackColor = False
        '
        'Company_Info
        '
        Me.Company_Info.AllowUserToAddRows = False
        Me.Company_Info.AllowUserToDeleteRows = False
        Me.Company_Info.AllowUserToResizeColumns = False
        Me.Company_Info.AllowUserToResizeRows = False
        Me.Company_Info.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.Company_Info.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Company_Info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Company_Info.ColumnHeadersVisible = False
        Me.Company_Info.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.com_info, Me.com_select})
        Me.TableLayoutPanel1.SetColumnSpan(Me.Company_Info, 7)
        Me.Company_Info.Location = New System.Drawing.Point(30, 118)
        Me.Company_Info.Margin = New System.Windows.Forms.Padding(0)
        Me.Company_Info.Name = "Company_Info"
        Me.Company_Info.ReadOnly = True
        Me.Company_Info.RowHeadersVisible = False
        Me.Company_Info.RowHeadersWidth = 51
        Me.TableLayoutPanel1.SetRowSpan(Me.Company_Info, 4)
        Me.Company_Info.RowTemplate.Height = 17
        Me.Company_Info.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Company_Info.Size = New System.Drawing.Size(415, 69)
        Me.Company_Info.TabIndex = 3
        '
        'com_info
        '
        Me.com_info.HeaderText = "com_info"
        Me.com_info.MinimumWidth = 6
        Me.com_info.Name = "com_info"
        Me.com_info.ReadOnly = True
        Me.com_info.Width = 143
        '
        'com_select
        '
        Me.com_select.HeaderText = "com_select"
        Me.com_select.MinimumWidth = 6
        Me.com_select.Name = "com_select"
        Me.com_select.ReadOnly = True
        Me.com_select.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.com_select.Width = 270
        '
        'Label1
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label1, 3)
        Me.Label1.Location = New System.Drawing.Point(473, 64)
        Me.Label1.Margin = New System.Windows.Forms.Padding(0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(274, 18)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "「検収印押印欄」"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Seal_Datagridview
        '
        Me.Seal_Datagridview.AllowUserToAddRows = False
        Me.Seal_Datagridview.AllowUserToDeleteRows = False
        Me.Seal_Datagridview.AllowUserToResizeColumns = False
        Me.Seal_Datagridview.AllowUserToResizeRows = False
        Me.Seal_Datagridview.BackgroundColor = System.Drawing.SystemColors.ControlLightLight
        Me.Seal_Datagridview.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Seal_Datagridview.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.Seal_Datagridview.ColumnHeadersHeight = 22
        Me.Seal_Datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Seal_Datagridview.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.minister, Me.supervisor, Me.project_administrator})
        Me.TableLayoutPanel1.SetColumnSpan(Me.Seal_Datagridview, 3)
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Seal_Datagridview.DefaultCellStyle = DataGridViewCellStyle9
        Me.Seal_Datagridview.GridColor = System.Drawing.SystemColors.ControlDarkDark
        Me.Seal_Datagridview.Location = New System.Drawing.Point(473, 100)
        Me.Seal_Datagridview.Margin = New System.Windows.Forms.Padding(0)
        Me.Seal_Datagridview.Name = "Seal_Datagridview"
        Me.Seal_Datagridview.RowHeadersVisible = False
        Me.Seal_Datagridview.RowHeadersWidth = 51
        Me.TableLayoutPanel1.SetRowSpan(Me.Seal_Datagridview, 6)
        Me.Seal_Datagridview.RowTemplate.Height = 27
        Me.Seal_Datagridview.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Seal_Datagridview.Size = New System.Drawing.Size(273, 103)
        Me.Seal_Datagridview.TabIndex = 13
        '
        'minister
        '
        Me.minister.HeaderText = "営業"
        Me.minister.MinimumWidth = 6
        Me.minister.Name = "minister"
        Me.minister.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.minister.Width = 80
        '
        'supervisor
        '
        Me.supervisor.HeaderText = "リーダー"
        Me.supervisor.MinimumWidth = 6
        Me.supervisor.Name = "supervisor"
        Me.supervisor.Width = 80
        '
        'project_administrator
        '
        Me.project_administrator.HeaderText = "ﾌﾟﾛｼﾞｪｸﾄ管理者"
        Me.project_administrator.MinimumWidth = 6
        Me.project_administrator.Name = "project_administrator"
        Me.project_administrator.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.project_administrator.Width = 112
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label4, 3)
        Me.Label4.Location = New System.Drawing.Point(473, 82)
        Me.Label4.Margin = New System.Windows.Forms.Padding(0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(274, 18)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "依頼元押印欄"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'reports
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.reports, 3)
        Me.reports.Font = New System.Drawing.Font("SimSun", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.reports.Location = New System.Drawing.Point(237, 20)
        Me.reports.Margin = New System.Windows.Forms.Padding(0)
        Me.reports.Name = "reports"
        Me.reports.Size = New System.Drawing.Size(210, 44)
        Me.reports.TabIndex = 2
        Me.reports.Text = "作　業　報　告　書"
        Me.reports.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.TableLayoutPanel1.SetColumnSpan(Me.Label3, 2)
        Me.Label3.Location = New System.Drawing.Point(30, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 20)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "(標準版)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Report_Date
        '
        Me.Report_Date.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Report_Date.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Report_Date.Font = New System.Drawing.Font("MS UI Gothic", 12.0!)
        Me.Report_Date.Location = New System.Drawing.Point(301, 82)
        Me.Report_Date.Margin = New System.Windows.Forms.Padding(0)
        Me.Report_Date.Name = "Report_Date"
        Me.Report_Date.ReadOnly = True
        Me.Report_Date.Size = New System.Drawing.Size(86, 23)
        Me.Report_Date.TabIndex = 18
        Me.Report_Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Commute
        '
        Me.Commute.Font = New System.Drawing.Font("SimSun", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Commute.FormattingEnabled = True
        Me.Commute.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Commute.ItemHeight = 14
        Me.Commute.Location = New System.Drawing.Point(387, 244)
        Me.Commute.Margin = New System.Windows.Forms.Padding(0)
        Me.Commute.Name = "Commute"
        Me.Commute.Size = New System.Drawing.Size(60, 22)
        Me.Commute.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label5.Location = New System.Drawing.Point(301, 244)
        Me.Label5.Margin = New System.Windows.Forms.Padding(0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 22)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "開始時間："
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Excel_Button
        '
        Me.Excel_Button.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Excel_Button.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Excel_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Excel_Button.Location = New System.Drawing.Point(473, 244)
        Me.Excel_Button.Margin = New System.Windows.Forms.Padding(0)
        Me.Excel_Button.Name = "Excel_Button"
        Me.Excel_Button.Size = New System.Drawing.Size(90, 22)
        Me.Excel_Button.TabIndex = 15
        Me.Excel_Button.Text = "エクセル出力"
        Me.Excel_Button.UseVisualStyleBackColor = False
        '
        'Calendar_Panel
        '
        Me.Calendar_Panel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Calendar_Panel.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Calendar_Panel.ColumnCount = 26
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 26.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.Calendar_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.Calendar_Panel.Controls.Add(Me.Calendar_View, 3, 2)
        Me.Calendar_Panel.Location = New System.Drawing.Point(0, 0)
        Me.Calendar_Panel.Margin = New System.Windows.Forms.Padding(0)
        Me.Calendar_Panel.Name = "Calendar_Panel"
        Me.Calendar_Panel.RowCount = 19
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 13.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.Calendar_Panel.Size = New System.Drawing.Size(788, 616)
        Me.Calendar_Panel.TabIndex = 9
        '
        'Calendar_View
        '
        Me.Calendar_View.AllowUserToAddRows = False
        Me.Calendar_View.AllowUserToDeleteRows = False
        Me.Calendar_View.AllowUserToResizeColumns = False
        Me.Calendar_View.AllowUserToResizeRows = False
        Me.Calendar_View.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.Calendar_View.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Calendar_View.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.Calendar_View.ColumnHeadersHeight = 35
        Me.Calendar_View.ColumnHeadersVisible = False
        Me.Calendar_View.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Sunday, Me.Monday, Me.Tuesday, Me.Wednesday, Me.Thursday, Me.Friday, Me.Saturday})
        Me.Calendar_Panel.SetColumnSpan(Me.Calendar_View, 20)
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Calendar_View.DefaultCellStyle = DataGridViewCellStyle11
        Me.Calendar_View.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Calendar_View.Location = New System.Drawing.Point(90, 64)
        Me.Calendar_View.Margin = New System.Windows.Forms.Padding(0)
        Me.Calendar_View.Name = "Calendar_View"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Calendar_View.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.Calendar_View.RowHeadersVisible = False
        Me.Calendar_View.RowHeadersWidth = 51
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Calendar_View.RowsDefaultCellStyle = DataGridViewCellStyle13
        Me.Calendar_Panel.SetRowSpan(Me.Calendar_View, 15)
        Me.Calendar_View.RowTemplate.Height = 80
        Me.Calendar_View.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Calendar_View.Size = New System.Drawing.Size(596, 461)
        Me.Calendar_View.TabIndex = 0
        '
        'Sunday
        '
        Me.Sunday.HeaderText = "日"
        Me.Sunday.MinimumWidth = 6
        Me.Sunday.Name = "Sunday"
        Me.Sunday.Width = 85
        '
        'Monday
        '
        Me.Monday.HeaderText = "月"
        Me.Monday.MinimumWidth = 6
        Me.Monday.Name = "Monday"
        Me.Monday.Width = 85
        '
        'Tuesday
        '
        Me.Tuesday.HeaderText = "火"
        Me.Tuesday.MinimumWidth = 6
        Me.Tuesday.Name = "Tuesday"
        Me.Tuesday.Width = 85
        '
        'Wednesday
        '
        Me.Wednesday.HeaderText = "水"
        Me.Wednesday.MinimumWidth = 6
        Me.Wednesday.Name = "Wednesday"
        Me.Wednesday.Width = 85
        '
        'Thursday
        '
        Me.Thursday.HeaderText = "木"
        Me.Thursday.MinimumWidth = 6
        Me.Thursday.Name = "Thursday"
        Me.Thursday.Width = 85
        '
        'Friday
        '
        Me.Friday.HeaderText = "金"
        Me.Friday.MinimumWidth = 6
        Me.Friday.Name = "Friday"
        Me.Friday.Width = 85
        '
        'Saturday
        '
        Me.Saturday.HeaderText = "土"
        Me.Saturday.MinimumWidth = 6
        Me.Saturday.Name = "Saturday"
        Me.Saturday.Width = 85
        '
        'RestTime_Panel
        '
        Me.RestTime_Panel.ColumnCount = 26
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.RestTime_Panel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160.0!))
        Me.RestTime_Panel.Controls.Add(Me.Dinner_Label, 6, 11)
        Me.RestTime_Panel.Controls.Add(Me.Label8, 13, 11)
        Me.RestTime_Panel.Controls.Add(Me.Label9, 13, 9)
        Me.RestTime_Panel.Controls.Add(Me.Lunch_Label, 6, 9)
        Me.RestTime_Panel.Controls.Add(Me.Label10, 7, 7)
        Me.RestTime_Panel.Controls.Add(Me.Site_ComboBox, 10, 7)
        Me.RestTime_Panel.Controls.Add(Me.Rest_Button, 10, 13)
        Me.RestTime_Panel.Controls.Add(Me.Dinner_StartTime, 10, 11)
        Me.RestTime_Panel.Controls.Add(Me.Dinner_EndTime, 14, 11)
        Me.RestTime_Panel.Controls.Add(Me.Lunch_StartTime, 10, 9)
        Me.RestTime_Panel.Controls.Add(Me.Lunch_EndTime, 14, 9)
        Me.RestTime_Panel.Location = New System.Drawing.Point(0, 0)
        Me.RestTime_Panel.Margin = New System.Windows.Forms.Padding(2)
        Me.RestTime_Panel.Name = "RestTime_Panel"
        Me.RestTime_Panel.RowCount = 19
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.RestTime_Panel.Size = New System.Drawing.Size(785, 616)
        Me.RestTime_Panel.TabIndex = 3
        '
        'Dinner_Label
        '
        Me.Dinner_Label.AutoSize = True
        Me.RestTime_Panel.SetColumnSpan(Me.Dinner_Label, 4)
        Me.Dinner_Label.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dinner_Label.Location = New System.Drawing.Point(180, 256)
        Me.Dinner_Label.Margin = New System.Windows.Forms.Padding(0)
        Me.Dinner_Label.Name = "Dinner_Label"
        Me.Dinner_Label.Size = New System.Drawing.Size(120, 20)
        Me.Dinner_Label.TabIndex = 4
        Me.Dinner_Label.Text = "夕方の休憩時間："
        Me.Dinner_Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label8.Location = New System.Drawing.Point(390, 256)
        Me.Label8.Margin = New System.Windows.Forms.Padding(0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "～"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label9.Location = New System.Drawing.Point(390, 216)
        Me.Label9.Margin = New System.Windows.Forms.Padding(0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(30, 20)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "～"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lunch_Label
        '
        Me.Lunch_Label.AutoSize = True
        Me.RestTime_Panel.SetColumnSpan(Me.Lunch_Label, 4)
        Me.Lunch_Label.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lunch_Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lunch_Label.Location = New System.Drawing.Point(180, 216)
        Me.Lunch_Label.Margin = New System.Windows.Forms.Padding(0)
        Me.Lunch_Label.Name = "Lunch_Label"
        Me.Lunch_Label.Size = New System.Drawing.Size(120, 20)
        Me.Lunch_Label.TabIndex = 1
        Me.Lunch_Label.Text = "午後の休憩時間："
        Me.Lunch_Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Label10, 3)
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label10.Location = New System.Drawing.Point(212, 176)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(86, 20)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "現場："
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Site_ComboBox
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Site_ComboBox, 7)
        Me.Site_ComboBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Site_ComboBox.FormattingEnabled = True
        Me.Site_ComboBox.Location = New System.Drawing.Point(300, 176)
        Me.Site_ComboBox.Margin = New System.Windows.Forms.Padding(0)
        Me.Site_ComboBox.Name = "Site_ComboBox"
        Me.Site_ComboBox.Size = New System.Drawing.Size(210, 20)
        Me.Site_ComboBox.TabIndex = 9
        '
        'Rest_Button
        '
        Me.Rest_Button.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.RestTime_Panel.SetColumnSpan(Me.Rest_Button, 7)
        Me.Rest_Button.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Rest_Button.FlatAppearance.BorderSize = 0
        Me.Rest_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rest_Button.Location = New System.Drawing.Point(300, 296)
        Me.Rest_Button.Margin = New System.Windows.Forms.Padding(0)
        Me.Rest_Button.Name = "Rest_Button"
        Me.Rest_Button.Size = New System.Drawing.Size(210, 32)
        Me.Rest_Button.TabIndex = 10
        Me.Rest_Button.Text = "確認"
        Me.Rest_Button.UseVisualStyleBackColor = False
        '
        'Dinner_StartTime
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Dinner_StartTime, 3)
        Me.Dinner_StartTime.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dinner_StartTime.FormattingEnabled = True
        Me.Dinner_StartTime.Location = New System.Drawing.Point(300, 256)
        Me.Dinner_StartTime.Margin = New System.Windows.Forms.Padding(0)
        Me.Dinner_StartTime.Name = "Dinner_StartTime"
        Me.Dinner_StartTime.Size = New System.Drawing.Size(90, 20)
        Me.Dinner_StartTime.TabIndex = 13
        '
        'Dinner_EndTime
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Dinner_EndTime, 3)
        Me.Dinner_EndTime.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dinner_EndTime.FormattingEnabled = True
        Me.Dinner_EndTime.Location = New System.Drawing.Point(420, 256)
        Me.Dinner_EndTime.Margin = New System.Windows.Forms.Padding(0)
        Me.Dinner_EndTime.Name = "Dinner_EndTime"
        Me.Dinner_EndTime.Size = New System.Drawing.Size(90, 20)
        Me.Dinner_EndTime.TabIndex = 14
        '
        'Lunch_StartTime
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Lunch_StartTime, 3)
        Me.Lunch_StartTime.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lunch_StartTime.FormattingEnabled = True
        Me.Lunch_StartTime.Location = New System.Drawing.Point(300, 216)
        Me.Lunch_StartTime.Margin = New System.Windows.Forms.Padding(0)
        Me.Lunch_StartTime.Name = "Lunch_StartTime"
        Me.Lunch_StartTime.Size = New System.Drawing.Size(90, 20)
        Me.Lunch_StartTime.TabIndex = 11
        '
        'Lunch_EndTime
        '
        Me.RestTime_Panel.SetColumnSpan(Me.Lunch_EndTime, 3)
        Me.Lunch_EndTime.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lunch_EndTime.FormattingEnabled = True
        Me.Lunch_EndTime.Location = New System.Drawing.Point(420, 216)
        Me.Lunch_EndTime.Margin = New System.Windows.Forms.Padding(0)
        Me.Lunch_EndTime.Name = "Lunch_EndTime"
        Me.Lunch_EndTime.Size = New System.Drawing.Size(90, 20)
        Me.Lunch_EndTime.TabIndex = 12
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1068, 640)
        Me.ControlBox = False
        Me.Controls.Add(Me.ReportDetailBox)
        Me.Controls.Add(Me.RepBox)
        Me.Controls.Add(Me.TittleBox)
        Me.Controls.Add(Me.MenuBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MinimumSize = New System.Drawing.Size(900, 581)
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.MenuBox.ResumeLayout(False)
        Me.MenuBox.PerformLayout()
        Me.TittleBox.ResumeLayout(False)
        Me.TittleBox.PerformLayout()
        Me.CtlBox.ResumeLayout(False)
        Me.FucBox.ResumeLayout(False)
        Me.ManageTittle.ResumeLayout(False)
        Me.ManageTittle.PerformLayout()
        Me.ProTittleBox.ResumeLayout(False)
        Me.ProTittleBox.PerformLayout()
        Me.ConTittleBox.ResumeLayout(False)
        Me.ConTittleBox.PerformLayout()
        Me.ReportDetailBox.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel1.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        CType(Me.Reports_Detail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Company_Info, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Seal_Datagridview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Calendar_Panel.ResumeLayout(False)
        CType(Me.Calendar_View, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RestTime_Panel.ResumeLayout(False)
        Me.RestTime_Panel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MenuBox As Panel
    Friend WithEvents RepBox As Panel
    Friend WithEvents TittleBox As Panel
    Friend WithEvents ReportDetailBox As Panel
    Friend WithEvents MinButton As Button
    Friend WithEvents MaxButton As Button
    Friend WithEvents CloseButton As Button
    Friend WithEvents CtlBox As Panel
    Friend WithEvents FucBox As Panel
    Friend WithEvents ConTittleBox As Panel
    Friend WithEvents MarginBottonBox As Panel
    Friend WithEvents MarginTopBox As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Confirm As Button
    Friend WithEvents Product As Button
    Friend WithEvents FinishStateLabel As Label
    Friend WithEvents FucLabel As Label
    Friend WithEvents Insert As Button
    Friend WithEvents ProTittleBox As Panel
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Report_Content As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Reports_Detail As DataGridView
    Friend WithEvents Submit_Button As Button
    Friend WithEvents Company_Info As DataGridView
    Friend WithEvents com_info As DataGridViewTextBoxColumn
    Friend WithEvents com_select As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents Seal_Datagridview As DataGridView
    Friend WithEvents Label4 As Label
    Friend WithEvents reports As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Commute As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ReportTittle As Label
    Friend WithEvents Report_Date As TextBox
    Friend WithEvents dates As DataGridViewTextBoxColumn
    Friend WithEvents weeks As DataGridViewTextBoxColumn
    Friend WithEvents start_time As DataGridViewTextBoxColumn
    Friend WithEvents end_time As DataGridViewTextBoxColumn
    Friend WithEvents worktime As DataGridViewTextBoxColumn
    Friend WithEvents reports_content As DataGridViewTextBoxColumn
    Friend WithEvents Excel_Button As Button
    Friend WithEvents NameText As TextBox
    Friend WithEvents minister As DataGridViewImageColumn
    Friend WithEvents supervisor As DataGridViewImageColumn
    Friend WithEvents project_administrator As DataGridViewImageColumn
    Friend WithEvents RestTime_Panel As TableLayoutPanel
    Friend WithEvents Dinner_Label As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Lunch_Label As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Site_ComboBox As ComboBox
    Friend WithEvents Rest_Button As Button
    Friend WithEvents Dinner_StartTime As ComboBox
    Friend WithEvents Dinner_EndTime As ComboBox
    Friend WithEvents Lunch_StartTime As ComboBox
    Friend WithEvents Lunch_EndTime As ComboBox
    Friend WithEvents Manage As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Calendar_Panel As TableLayoutPanel
    Friend WithEvents Calendar_View As DataGridView
    Friend WithEvents Sunday As DataGridViewTextBoxColumn
    Friend WithEvents Monday As DataGridViewTextBoxColumn
    Friend WithEvents Tuesday As DataGridViewTextBoxColumn
    Friend WithEvents Wednesday As DataGridViewTextBoxColumn
    Friend WithEvents Thursday As DataGridViewTextBoxColumn
    Friend WithEvents Friday As DataGridViewTextBoxColumn
    Friend WithEvents Saturday As DataGridViewTextBoxColumn
    Friend WithEvents ManageTittle As Panel
    Friend WithEvents ManagerLabel As Label
End Class
