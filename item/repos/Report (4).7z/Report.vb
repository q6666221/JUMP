﻿Imports System.Data.SqlClient
Public Class Report
    Shared seal As Image = New Bitmap(80, 80)

    ''' <summary>
    ''' 作業報告書のデータの初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Reprot_load(sender As Object, e As EventArgs) Handles MyBase.Load

        Init()
        'MessageViewの初期化
        MessageViewInit()

        GetReports()

        ''SealViewの初期化
        'SealView.Rows.Add(1)
        'SealView.CurrentRow.Height = 80
        'SealViewInit()
    End Sub

    Private Sub Init()
        Dim now As DateTime = DateTime.Now
        Year.Text = now.Year
        Mon.Text = now.Month
    End Sub

    ''' <summary>
    ''' MessageViewの初期化
    ''' </summary>
    Private Sub MessageViewInit()
        'メッセージ列のイニシャライズ
        MessageView.Rows.Add("所属会社", employee.c_name)
        MessageView.Rows.Add("所属部署", employee.d_name)
        MessageView.Rows.Add("氏名", employee.e_name)
        MessageView.Rows.Add("ﾕｰｻﾞ名/ﾌﾟﾛｼﾞｪｸﾄ名", employee.u_name)

    End Sub

    Private Sub Mon_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Mon.SelectedIndexChanged
        GetReports()
    End Sub

    Private Sub GetReports()
        ReportView.Rows.Clear()
        Dim firstDay = New DateTime(Year.Text, Mon.Text, 1)
        Tools.GetRid(conn, Me.employee, firstDay)
        Dim sql = "select start_time,end_time,work_time,work_content from reports_detail where r_id = ?"
        Dim table = Tools.GetData(sql, conn, employee.r_id)
        Dim num As Integer = 0
        For i = 0 To Date.DaysInMonth(Year.Text, Mon.Text) - 1
            Dim week = Tools.GetWeekOfDay(firstDay.AddDays(i))
            ReportView.Rows.Add((i + 1), week)
            Select Case week
                Case "(土)"
                    ReportView.Rows(i).Cells(0).Style.ForeColor = Color.Blue
                    ReportView.Rows(i).Cells(1).Style.ForeColor = Color.Blue
                Case "(日)"
                    ReportView.Rows(i).Cells(0).Style.ForeColor = Color.Red
                    ReportView.Rows(i).Cells(1).Style.ForeColor = Color.Red
            End Select
            If table.Rows.Count > num AndAlso (i + 1) = table.Rows(num).Field(Of DateTime)("start_time").Day Then
                Dim start_time = table.Rows(i).Field(Of DateTime)("start_time")
                Dim end_time = table.Rows(i).Field(Of DateTime)("end_time")
                Dim work_time = New TimeSpan(table.Rows(i).Field(Of Long)("work_time")).ToString.Split(":")
                Dim work_content = table.Rows(i).Field(Of String)("work_content")
                ReportView.Rows(i).SetValues((i + 1), week, start_time.ToShortTimeString, end_time.ToShortTimeString,
                                             work_time(0) & ":" & work_time(1), work_content)
                num += 1
            End If
        Next i
        ReportView.Rows.Add(1)
        Dim total_time_arr = employee.total_worktime.ToString.Split(":")
        ReportView.Rows.Add("合計", Nothing, Nothing, Nothing, total_time_arr(0) & ":" & total_time_arr(1), Nothing)
    End Sub





    ''' <summary>
    ''' ReportView中のworktimeを設定
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ReportViewWorkTime(sender As Object, e As EventArgs) Handles ReportView.CurrentCellDirtyStateChanged
        '重要な情報を取り出す
        Dim startTime = ReportView.CurrentRow.Cells(2).Value
        Dim endTime = ReportView.CurrentRow.Cells(3).Value

        'starttimeとendtimeはnothingじゃないと、以下のstatementを実行する
        If startTime <> "" And endTime <> "" Then
            startTime = Split(startTime, ":")
            endTime = Split(endTime, ":")
            Dim workTime = ""

            startTime = New TimeSpan(startTime(0), startTime(1), 0)
            endTime = New TimeSpan(endTime(0), endTime(1), 0)
            If endTime > startTime Then
                Dim arr = Split((endTime - startTime).ToString, ":")
                Dim num = arr(0) / 6
                If num > 1 Or (num = 1 And arr(1) > 0) Then
                    workTime = (CType(arr(0), Integer) - Int(num) * 1) & ":" & arr(1)
                Else
                    workTime = CType(arr(0), Integer) & ":" & arr(1)
                End If

            Else
                workTime = "エラー"
                ReportView.CurrentRow.Cells(3).Style.ForeColor = Red.Color
            End If
            ReportView.CurrentRow.Cells(3).Value = workTime


            GetSumTime()
        ElseIf startTime = "" And endTime = "" Then
            ReportView.CurrentRow.Cells(3).Value = ""
        End If
    End Sub

    '''' <summary>
    '''' 通勤時間の初期化
    '''' </summary>
    '''' <param name="sender"></param>
    '''' <param name="e"></param>
    'Private Sub WorkTimeListChanged(sender As Object, e As EventArgs) Handles WorkTimeList.SelectedIndexChanged
    '    Dim workTime = WorkTimeList.Text
    '    Dim year = YearMonView.Rows(0).Cells(0).Value
    '    Dim mon = YearMonView.Rows(0).Cells(1).Value

    '    If year <> "" And mon <> "" Then
    '        year = CType(YearMonView.Rows(0).Cells(0).Value, Integer)
    '        mon = CType(YearMonView.Rows(0).Cells(1).Value, Integer)

    '        Dim arr = workTime.Split(":")
    '        Dim days As Integer = Getdays(year, mon)
    '        For i = 0 To days - 1
    '            Dim color = ReportView.Rows(i).Cells(0).Style.ForeColor
    '            If color <> Red.Color And color <> Blue.Color Then
    '                Dim endTime As Integer = CType(arr(0), Integer) + 9
    '                ReportView.Rows(i).Cells(1).Value = workTime
    '                ReportView.Rows(i).Cells(2).Value = endTime.ToString() & ":" & arr(1)
    '                ReportView.Rows(i).Cells(3).Value = "8:00"
    '            End If
    '        Next i
    '        GetSumTime()
    '    End If
    'End Sub

    '' <summary>
    '' 総時間を取り出す
    '' </summary>
    Private Sub GetSumTime()
        Dim sumHour = 0
        Dim sumMin = 0
        For i = 0 To 30
            Dim time = Split(ReportView.Rows(i).Cells(3).Value, ":")
            If time.Length = 2 Then
                sumHour += CType(time(0), Integer)
                sumMin += CType(time(1), Integer)
            End If
        Next i

        sumHour += Int(sumMin / 60)
        sumMin = sumMin Mod 60
        Dim min = sumMin.ToString()
        If sumMin = 0 Then
            min = "00"
        End If
        Dim sumTime = sumHour & ":" & min

        ReportView.Rows(31).Cells(3).Value = sumTime
    End Sub


    '''' <summary>
    '''' メッセージを登録する
    '''' </summary>
    '''' <param name="sender"></param>
    '''' <param name="e"></param>
    'Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
    '    Dim year = YearMonView.Rows(0).Cells(0).Value
    '    Dim mon = YearMonView.Rows(0).Cells(1).Value
    '    Dim cid = MessageView.Rows(0).Cells(1).Value
    '    Dim did = MessageView.Rows(1).Cells(1).Value
    '    Dim eid = MessageView.Rows(2).Cells(1).Value

    '    If year <> Nothing And mon <> Nothing And cid <> Nothing And did <> Nothing And eid <> Nothing Then
    '        Dim e_id As Integer = MessageView.Rows(2).Cells(1).Value
    '        Dim r_date As String = YearMonView.Rows(0).Cells(0).Value & "/" & YearMonView.Rows(0).Cells(1).Value
    '        Dim sql = "select r_id from reports where e_id = ? and r_date = ?"
    '        Dim table = Tools.GetData(sql, conn, e_id, r_date)
    '        Dim num = UpdateReports(table, e_id, r_date)
    '        Dim r_id = Tools.GetData(sql, conn, e_id, r_date).Rows(0).ItemArray(0).ToString()
    '        Dim num1 = UpdateReportsDetail(table, r_id, year, mon)
    '        MessageBox.Show("Reports表の中の影響される行目：" & num & vbLf & "ReportsDetail表の中の影響される行目：" & num1)
    '    Else
    '        MessageBox.Show("入力したデータは間違いですから、も一度ご入力ください")
    '    End If

    'End Sub

    '''' <summary>
    '''' Reports表に対して更新する
    '''' </summary>
    '''' <param name="table"></param>
    '''' <param name="e_id"></param>
    '''' <param name="r_date"></param>
    'Private Function UpdateReports(table As DataTable, e_id As Integer, r_date As String) As Integer
    '    Dim sql = "insert into reports values (next value for reports_sequence,?,?,?,?,?,?,?)"
    '    If table.Rows.Count > 0 Then
    '        sql = "update reports set u_id = ?,e_id = ?,r_date = ?,total_worktime = ?,overtime = ?,important_content = ?,create_time = ? where r_id = " & table.Rows(0).ItemArray(0)
    '    End If
    '    Dim u_id As Integer = MessageView.Rows(3).Cells(1).Value
    '    Dim total_worktime As String = ReportView.Rows(31).Cells(3).Value
    '    Dim important_content = WorkText.Text
    '    Dim now = Date.Now()
    '    Return Tools.SetData(sql, conn, u_id, e_id, r_date, total_worktime, total_worktime, important_content, now)
    '    Console.WriteLine("実行行目：" & Int())
    'End Function

    '''' <summary>
    '''' ReportsDetail表に対して更新する
    '''' </summary>
    '''' <param name="table"></param>
    '''' <param name="r_id"></param>
    '''' <param name="year"></param>
    '''' <param name="mon"></param>
    'Private Function UpdateReportsDetail(table As DataTable, r_id As String, year As Integer, mon As Integer) As Integer
    '    Dim days = Getdays(year, mon)
    '    Dim sql = "insert into reports_detail values (?,?,?,?,?)"
    '    If table.Rows.Count > 0 Then
    '        Dim sql1 = "delete from reports_detail where r_id = " & table.Rows(0).ItemArray(0)
    '        Tools.SetData(sql1, conn)
    '    End If
    '    Dim sum = 0
    '    For i = 0 To days - 1
    '        Dim time = ReportView.Rows(i).Cells(3).Value
    '        If time <> Nothing Then
    '            Dim arr = time.ToString().Split(":")
    '            If arr.Length > 1 Then
    '                Dim startArr = ReportView.Rows(i).Cells(1).Value.ToString().Split(":")
    '                Dim startTime = New DateTime(year, mon, i + 1, startArr(0), startArr(1), 0)
    '                Dim endArr = ReportView.Rows(i).Cells(2).Value.ToString().Split(":")
    '                Dim endTime = New DateTime(year, mon, i + 1, endArr(0), endArr(1), 0)
    '                Dim workTime = ReportView.Rows(i).Cells(3).Value.ToString()
    '                Dim workContent = ReportView.Rows(i).Cells(4).Value
    '                sum += Tools.SetData(sql, conn, r_id, startTime, endTime, workTime, workContent)
    '            End If

    '        End If
    '    Next i
    '    Console.WriteLine("実行行目：" & sum)
    '    Return sum
    'End Function

    ''' <summary>
    ''' SealViewの初期化
    ''' </summary>
    Private Sub SealViewInit()
        Dim column1 = CType(SealView.Columns(0), DataGridViewImageColumn)
        Dim column2 = CType(SealView.Columns(1), DataGridViewImageColumn)
        Dim column3 = CType(SealView.Columns(2), DataGridViewImageColumn)
        column1.Image = seal
        column2.Image = seal
        column3.Image = seal
    End Sub

    ''' <summary>
    ''' 印鑑の追加または削除
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub SealView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles SealView.CellContentClick
        '重要なメッセージを取り出す
        Dim column1 = CType(SealView.Columns(0), DataGridViewImageColumn)
        Dim column2 = CType(SealView.Columns(1), DataGridViewImageColumn)
        Dim column3 = CType(SealView.Columns(2), DataGridViewImageColumn)

        'どこで印鑑を入力することが判断
        If column1.Image Is seal And column2.Image Is seal And column3.Image Is seal Then
            Dim e_id = MessageView.Rows(2).Cells(1).Value
            If e_id <> Nothing Then
                Dim sql = "select u_id,p_id,seal　from employees where e_id = ?"
                Dim table = Tools.GetData(sql, conn, e_id)
                Dim row = table.Rows(0)
                'プロジェクト管理者欄で印鑑を入力するかどうか
                If row.ItemArray(0).ToString <> Nothing Then
                    column3.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                End If

                '部長欄か課長欄かどちら印鑑を入力するの判断
                Select Case row.ItemArray(1)
                    Case 2
                        column1.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                    Case 3
                        column2.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                End Select
            End If
        Else
            '入力した印鑑をクリアする
            SealViewInit()
        End If
    End Sub

    'Private Sub Mon_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Mon.SelectedIndexChanged
    '    Dim yearVal As Integer = Me.Year.Text
    '    Dim monVal As Integer = Me.Mon.Text


    '    Dim year = CType(YearMonView.Rows(0).Cells(0).Value, Integer)
    '    Dim mon = CType(YearMonView.Rows(0).Cells(1).Value, Integer)
    '    Dim day = Getdays(year, mon)

    '    '年度か月度の変更する時は、starttime、endtimeとworktimeは全部で削除する
    '    For i = 0 To 30
    '        ReportView.
    '        ReportView.Rows(i).SetValues(Nothing, Nothing, Nothing, Nothing)
    '        ReportView.Rows(i).Cells(0).Style.ForeColor = Black.Color
    '        ReportView.Rows(i).Cells(3).Style.ForeColor = Black.Color
    '    Next i

    '    For i As Integer = 0 To day - 1
    '        Dim nowDate = New DateTime(year, mon, i + 1, 0, 0, 0)
    '        Dim oldDate As DateTime = New DateTime(year, 1, 1, 0, 0, 0)
    '        Dim days = Split((nowDate - oldDate).ToString(), ".")(0)
    '        If days = "00:00:00" Then
    '            days = 0
    '        End If
    '        Dim monNum As Integer = (year - 1 + Int((year - 1) / 4) - Int((year - 1) / 100) + Int((year - 1) / 400) + days + 1) Mod 7
    '        Select Case monNum
    '            Case 0
    '                ReportView.Rows(i).Cells(0).Style.ForeColor = Red.Color
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (日)"
    '            Case 1
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (月)"
    '            Case 2
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (火)"
    '            Case 3
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (水)"
    '            Case 4
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (木)"
    '            Case 5
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (金)"
    '            Case 6
    '                ReportView.Rows(i).Cells(0).Style.ForeColor = Blue.Color
    '                ReportView.Rows(i).Cells(0).Value = (i + 1) & " (土)"
    '        End Select
    '    Next i
    'End Sub
End Class
