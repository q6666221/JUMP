﻿Imports System.IO

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Report
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.ReportView = New System.Windows.Forms.DataGridView()
        Me.Tittle = New System.Windows.Forms.Label()
        Me.LimeGreen = New System.Windows.Forms.ColorDialog()
        Me.White = New System.Windows.Forms.ColorDialog()
        Me.Red = New System.Windows.Forms.ColorDialog()
        Me.Blue = New System.Windows.Forms.ColorDialog()
        Me.YearMonView = New System.Windows.Forms.DataGridView()
        Me.MessageView = New System.Windows.Forms.DataGridView()
        Me.Message = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MessageList = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.WorkTable = New System.Windows.Forms.Label()
        Me.WorkText = New System.Windows.Forms.TextBox()
        Me.WorkTittle = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.WorkTimeList = New System.Windows.Forms.ComboBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.SealView = New System.Windows.Forms.DataGridView()
        Me.Black = New System.Windows.Forms.ColorDialog()
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.day_week = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Start_Time = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.End_Time = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.time = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.content = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Year = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Mon = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.dep_manager = New System.Windows.Forms.DataGridViewImageColumn()
        Me.off_manager = New System.Windows.Forms.DataGridViewImageColumn()
        Me.pro_manager = New System.Windows.Forms.DataGridViewImageColumn()
        CType(Me.ReportView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.YearMonView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MessageView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SealView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportView
        '
        Me.ReportView.AllowUserToAddRows = False
        Me.ReportView.AllowUserToResizeColumns = False
        Me.ReportView.AllowUserToResizeRows = False
        Me.ReportView.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ReportView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.ReportView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ReportView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.day_week, Me.Start_Time, Me.End_Time, Me.time, Me.content})
        Me.ReportView.Location = New System.Drawing.Point(61, 332)
        Me.ReportView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ReportView.Name = "ReportView"
        Me.ReportView.RowHeadersVisible = False
        Me.ReportView.RowHeadersWidth = 51
        Me.ReportView.RowTemplate.Height = 27
        Me.ReportView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.ReportView.Size = New System.Drawing.Size(775, 876)
        Me.ReportView.TabIndex = 0
        '
        'Tittle
        '
        Me.Tittle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tittle.Font = New System.Drawing.Font("宋体", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Tittle.Location = New System.Drawing.Point(349, 26)
        Me.Tittle.Name = "Tittle"
        Me.Tittle.Size = New System.Drawing.Size(215, 40)
        Me.Tittle.TabIndex = 1
        Me.Tittle.Text = "作業報告書"
        Me.Tittle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LimeGreen
        '
        Me.LimeGreen.Color = System.Drawing.Color.LimeGreen
        '
        'White
        '
        Me.White.Color = System.Drawing.Color.White
        '
        'Red
        '
        Me.Red.Color = System.Drawing.Color.Red
        '
        'Blue
        '
        Me.Blue.Color = System.Drawing.Color.Blue
        '
        'YearMonView
        '
        Me.YearMonView.AllowUserToResizeColumns = False
        Me.YearMonView.AllowUserToResizeRows = False
        Me.YearMonView.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!)
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.YearMonView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.YearMonView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.YearMonView.ColumnHeadersVisible = False
        Me.YearMonView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Year, Me.Mon})
        Me.YearMonView.Location = New System.Drawing.Point(349, 86)
        Me.YearMonView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.YearMonView.Name = "YearMonView"
        Me.YearMonView.RowHeadersVisible = False
        Me.YearMonView.RowHeadersWidth = 51
        Me.YearMonView.RowTemplate.Height = 27
        Me.YearMonView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.YearMonView.Size = New System.Drawing.Size(216, 31)
        Me.YearMonView.TabIndex = 7
        '
        'MessageView
        '
        Me.MessageView.AllowUserToAddRows = False
        Me.MessageView.AllowUserToResizeColumns = False
        Me.MessageView.AllowUserToResizeRows = False
        Me.MessageView.BackgroundColor = System.Drawing.SystemColors.Window
        Me.MessageView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MessageView.ColumnHeadersVisible = False
        Me.MessageView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Message, Me.MessageList})
        Me.MessageView.Location = New System.Drawing.Point(61, 155)
        Me.MessageView.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MessageView.Name = "MessageView"
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MessageView.RowHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.MessageView.RowHeadersVisible = False
        Me.MessageView.RowHeadersWidth = 51
        Me.MessageView.RowTemplate.Height = 27
        Me.MessageView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.MessageView.Size = New System.Drawing.Size(371, 135)
        Me.MessageView.TabIndex = 8
        '
        'Message
        '
        Me.Message.HeaderText = "Message"
        Me.Message.MinimumWidth = 6
        Me.Message.Name = "Message"
        Me.Message.ReadOnly = True
        Me.Message.Width = 138
        '
        'MessageList
        '
        Me.MessageList.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.MessageList.HeaderText = "MessageList"
        Me.MessageList.MinimumWidth = 6
        Me.MessageList.Name = "MessageList"
        Me.MessageList.Width = 137
        '
        'WorkTable
        '
        Me.WorkTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.WorkTable.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.WorkTable.Location = New System.Drawing.Point(141, 301)
        Me.WorkTable.Name = "WorkTable"
        Me.WorkTable.Size = New System.Drawing.Size(106, 22)
        Me.WorkTable.TabIndex = 9
        Me.WorkTable.Text = "作業報告欄"
        Me.WorkTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'WorkText
        '
        Me.WorkText.Location = New System.Drawing.Point(61, 1240)
        Me.WorkText.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.WorkText.Multiline = True
        Me.WorkText.Name = "WorkText"
        Me.WorkText.Size = New System.Drawing.Size(775, 124)
        Me.WorkText.TabIndex = 11
        '
        'WorkTittle
        '
        Me.WorkTittle.AutoSize = True
        Me.WorkTittle.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.WorkTittle.Location = New System.Drawing.Point(57, 1218)
        Me.WorkTittle.Name = "WorkTittle"
        Me.WorkTittle.Size = New System.Drawing.Size(119, 20)
        Me.WorkTittle.TabIndex = 12
        Me.WorkTittle.Text = "[特記事項］"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(59, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 15)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "（標準版）"
        '
        'WorkTimeList
        '
        Me.WorkTimeList.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!)
        Me.WorkTimeList.FormattingEnabled = True
        Me.WorkTimeList.Items.AddRange(New Object() {"0:00", "0:15", "0:30", "0:45", "1:00", "1:15", "1:30", "1:45", "2:00", "2:15", "2:30", "2:45", "3:00", "3:15", "3:30", "3:45", "4:00", "4:15", "4:30", "4:45", "5:00", "5:15", "5:30", "5:45", "6:00", "6:15", "6:30", "6:45", "7:00", "7:15", "7:30", "7:45", "8:00", "8:15", "8:30", "8:45", "9:00", "9:15", "9:30", "9:45", "10:00", "10:15", "10:30", "10:45", "11:00", "11:15", "11:30", "11:45", "12:00", "12:15", "12:30", "12:45", "13:00", "13:15", "13:30", "13:45", "14:00", "14:15", "14:30", "14:45", "15:00", "15:15", "15:30", "15:45", "16:00", "16:15", "16:30", "16:45", "17:00", "17:15", "17:30", "17:45", "18:00", "18:15", "18:30", "18:45", "19:00", "19:15", "19:30", "19:45", "20:00", "20:15", "20:30", "20:45", "21:00", "21:15", "21:30", "21:45", "22:00", "22:15", "22:30", "22:45", "23:00", "23:15", "23:30", "23:45", "24:00"})
        Me.WorkTimeList.Location = New System.Drawing.Point(589, 299)
        Me.WorkTimeList.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.WorkTimeList.Name = "WorkTimeList"
        Me.WorkTimeList.Size = New System.Drawing.Size(121, 23)
        Me.WorkTimeList.TabIndex = 14
        Me.WorkTimeList.Text = "通勤時間"
        '
        'SaveButton
        '
        Me.SaveButton.BackColor = System.Drawing.Color.White
        Me.SaveButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SaveButton.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.SaveButton.Location = New System.Drawing.Point(777, 296)
        Me.SaveButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 25)
        Me.SaveButton.TabIndex = 15
        Me.SaveButton.Text = "保存"
        Me.SaveButton.UseVisualStyleBackColor = False
        '
        'SealView
        '
        Me.SealView.AllowUserToAddRows = False
        Me.SealView.AllowUserToOrderColumns = True
        Me.SealView.AllowUserToResizeColumns = False
        Me.SealView.AllowUserToResizeRows = False
        Me.SealView.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 7.8!)
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SealView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.SealView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SealView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dep_manager, Me.off_manager, Me.pro_manager})
        Me.SealView.Location = New System.Drawing.Point(589, 125)
        Me.SealView.Margin = New System.Windows.Forms.Padding(4)
        Me.SealView.Name = "SealView"
        Me.SealView.ReadOnly = True
        Me.SealView.RowHeadersVisible = False
        Me.SealView.RowHeadersWidth = 51
        Me.SealView.RowTemplate.Height = 21
        Me.SealView.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.SealView.Size = New System.Drawing.Size(324, 141)
        Me.SealView.TabIndex = 16
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'day_week
        '
        DataGridViewCellStyle2.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!)
        DataGridViewCellStyle2.NullValue = Nothing
        Me.day_week.DefaultCellStyle = DataGridViewCellStyle2
        Me.day_week.HeaderText = "日付"
        Me.day_week.MinimumWidth = 6
        Me.day_week.Name = "day_week"
        Me.day_week.ReadOnly = True
        Me.day_week.Width = 65
        '
        'Start_Time
        '
        DataGridViewCellStyle3.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Start_Time.DefaultCellStyle = DataGridViewCellStyle3
        Me.Start_Time.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.Start_Time.HeaderText = "開始"
        Me.Start_Time.Items.AddRange(New Object() {"", "0:00", "0:15", "0:30", "0:45", "1:00", "1:15", "1:30", "1:45", "2:00", "2:15", "2:30", "2:45", "3:00", "3:15", "3:30", "3:45", "4:00", "4:15", "4:30", "4:45", "5:00", "5:15", "5:30", "5:45", "6:00", "6:15", "6:30", "6:45", "7:00", "7:15", "7:30", "7:45", "8:00", "8:15", "8:30", "8:45", "9:00", "9:15", "9:30", "9:45", "10:00", "10:15", "10:30", "10:45", "11:00", "11:15", "11:30", "11:45", "12:00", "12:15", "12:30", "12:45", "13:00", "13:15", "13:30", "13:45", "14:00", "14:15", "14:30", "14:45", "15:00", "15:15", "15:30", "15:45", "16:00", "16:15", "16:30", "16:45", "17:00", "17:15", "17:30", "17:45", "18:00", "18:15", "18:30", "18:45", "19:00", "19:15", "19:30", "19:45", "20:00", "20:15", "20:30", "20:45", "21:00", "21:15", "21:30", "21:45", "22:00", "22:15", "22:30", "22:45", "23:00", "23:15", "23:30", "23:45", "24:00", "24:15", "24:30", "24:45", "25:00", "25:15", "25:30", "25:45", "26:00", "26:15", "26:30", "26:45", "27:00", "27:15", "27:30", "27:45", "28:00", "28:15", "28:30", "28:45", "29:00", "29:15", "29:30", "29:45", "30:00", "30:15", "30:30", "30:45", "31:00", "31:15", "31:30", "31:45", "32:00", "32:15", "32:30", "32:45", "33:00"})
        Me.Start_Time.MinimumWidth = 6
        Me.Start_Time.Name = "Start_Time"
        Me.Start_Time.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Start_Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Start_Time.Width = 65
        '
        'End_Time
        '
        DataGridViewCellStyle4.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.End_Time.DefaultCellStyle = DataGridViewCellStyle4
        Me.End_Time.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.End_Time.HeaderText = "終了"
        Me.End_Time.Items.AddRange(New Object() {"", "0:00", "0:15", "0:30", "0:45", "1:00", "1:15", "1:30", "1:45", "2:00", "2:15", "2:30", "2:45", "3:00", "3:15", "3:30", "3:45", "4:00", "4:15", "4:30", "4:45", "5:00", "5:15", "5:30", "5:45", "6:00", "6:15", "6:30", "6:45", "7:00", "7:15", "7:30", "7:45", "8:00", "8:15", "8:30", "8:45", "9:00", "9:15", "9:30", "9:45", "10:00", "10:15", "10:30", "10:45", "11:00", "11:15", "11:30", "11:45", "12:00", "12:15", "12:30", "12:45", "13:00", "13:15", "13:30", "13:45", "14:00", "14:15", "14:30", "14:45", "15:00", "15:15", "15:30", "15:45", "16:00", "16:15", "16:30", "16:45", "17:00", "17:15", "17:30", "17:45", "18:00", "18:15", "18:30", "18:45", "19:00", "19:15", "19:30", "19:45", "20:00", "20:15", "20:30", "20:45", "21:00", "21:15", "21:30", "21:45", "22:00", "22:15", "22:30", "22:45", "23:00", "23:15", "23:30", "23:45", "24:00", "24:15", "24:30", "24:45", "25:00", "25:15", "25:30", "25:45", "26:00", "26:15", "26:30", "26:45", "27:00", "27:15", "27:30", "27:45", "28:00", "28:15", "28:30", "28:45", "29:00", "29:15", "29:30", "29:45", "30:00", "30:15", "30:30", "30:45", "31:00", "31:15", "31:30", "31:45", "32:00", "32:15", "32:30", "32:45", "33:00"})
        Me.End_Time.MinimumWidth = 6
        Me.End_Time.Name = "End_Time"
        Me.End_Time.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.End_Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.End_Time.Width = 65
        '
        'time
        '
        DataGridViewCellStyle5.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time.DefaultCellStyle = DataGridViewCellStyle5
        Me.time.HeaderText = "工数"
        Me.time.MinimumWidth = 6
        Me.time.Name = "time"
        Me.time.ReadOnly = True
        Me.time.Width = 65
        '
        'content
        '
        DataGridViewCellStyle6.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.content.DefaultCellStyle = DataGridViewCellStyle6
        Me.content.HeaderText = "作業内容"
        Me.content.MinimumWidth = 6
        Me.content.Name = "content"
        Me.content.Width = 300
        '
        'Year
        '
        DataGridViewCellStyle8.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.NullValue = "年度"
        Me.Year.DefaultCellStyle = DataGridViewCellStyle8
        Me.Year.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.Year.HeaderText = "Year"
        Me.Year.Items.AddRange(New Object() {"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"})
        Me.Year.MinimumWidth = 6
        Me.Year.Name = "Year"
        Me.Year.Width = 80
        '
        'Mon
        '
        DataGridViewCellStyle9.Font = New System.Drawing.Font("ＭＳ Ｐゴシック", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.NullValue = "月度"
        Me.Mon.DefaultCellStyle = DataGridViewCellStyle9
        Me.Mon.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.Mon.HeaderText = "Mon"
        Me.Mon.Items.AddRange(New Object() {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"})
        Me.Mon.MinimumWidth = 6
        Me.Mon.Name = "Mon"
        Me.Mon.Width = 80
        '
        'dep_manager
        '
        Me.dep_manager.HeaderText = "部長"
        Me.dep_manager.MinimumWidth = 6
        Me.dep_manager.Name = "dep_manager"
        Me.dep_manager.ReadOnly = True
        Me.dep_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dep_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.dep_manager.Width = 80
        '
        'off_manager
        '
        Me.off_manager.HeaderText = "課長"
        Me.off_manager.MinimumWidth = 6
        Me.off_manager.Name = "off_manager"
        Me.off_manager.ReadOnly = True
        Me.off_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.off_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.off_manager.Width = 80
        '
        'pro_manager
        '
        Me.pro_manager.HeaderText = "プロジェクト管理者"
        Me.pro_manager.MinimumWidth = 6
        Me.pro_manager.Name = "pro_manager"
        Me.pro_manager.ReadOnly = True
        Me.pro_manager.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.pro_manager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.pro_manager.Width = 80
        '
        'Report
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1113, 1055)
        Me.Controls.Add(Me.SealView)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.WorkTimeList)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.WorkTittle)
        Me.Controls.Add(Me.WorkText)
        Me.Controls.Add(Me.WorkTable)
        Me.Controls.Add(Me.MessageView)
        Me.Controls.Add(Me.YearMonView)
        Me.Controls.Add(Me.Tittle)
        Me.Controls.Add(Me.ReportView)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Report"
        Me.Text = "作業報告書"
        CType(Me.ReportView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.YearMonView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MessageView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SealView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private Sub MessageListInit()

    End Sub



    Friend WithEvents ReportView As DataGridView
    Friend WithEvents Tittle As Label
    Friend WithEvents LimeGreen As ColorDialog
    Friend WithEvents White As ColorDialog
    Friend WithEvents Red As ColorDialog
    Friend WithEvents Blue As ColorDialog
    Friend WithEvents YearMonView As DataGridView
    Friend WithEvents MessageView As DataGridView
    Friend WithEvents WorkTable As Label
    Friend WithEvents WorkText As TextBox
    Friend WithEvents WorkTittle As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Message As DataGridViewTextBoxColumn
    Friend WithEvents MessageList As DataGridViewComboBoxColumn
    Friend WithEvents WorkTimeList As ComboBox
    Friend WithEvents SaveButton As Button
    Friend WithEvents SealView As DataGridView
    Friend WithEvents Black As ColorDialog
    Friend WithEvents FileSystemWatcher1 As FileSystemWatcher
    Friend WithEvents day_week As DataGridViewTextBoxColumn
    Friend WithEvents Start_Time As DataGridViewComboBoxColumn
    Friend WithEvents End_Time As DataGridViewComboBoxColumn
    Friend WithEvents time As DataGridViewTextBoxColumn
    Friend WithEvents content As DataGridViewTextBoxColumn
    Friend WithEvents Year As DataGridViewComboBoxColumn
    Friend WithEvents Mon As DataGridViewComboBoxColumn
    Friend WithEvents dep_manager As DataGridViewImageColumn
    Friend WithEvents off_manager As DataGridViewImageColumn
    Friend WithEvents pro_manager As DataGridViewImageColumn
End Class
