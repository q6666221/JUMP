﻿Imports System.Data.SqlClient
Imports Excel = Microsoft.Office.Interop.Excel
Public Class Report
    Shared seal As Image = New Bitmap(80, 80)
    ''' <summary>
    ''' connectionの定義
    ''' </summary>
    Private connection As SqlConnection = New SqlConnection With {
            .ConnectionString = "Data Source = 192.168.3.6;Initial Catalog=Newelite;Persist Security Info=True;User ID=sa;Password=root"
        }

    ''' <summary>
    ''' 作業報告書のデータの初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Reprot_load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ClientSize = New Size(1000, 2000)
        'connectionを開く
        connection.Open()
        'YearMonViewのAutoSizeColumnsModeを設定
        YearMonView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        'MessageViewの初期化
        MessageViewInit()
        'ReportViewの初期化
        ReportViewInit()

        ''SumViewの初期化
        'SumViewInit()
        SealView.Rows.Add(1)
        SealView.CurrentRow.Height = 80
        SealViewInit()
    End Sub

    ''' <summary>
    ''' MessageViewの初期化
    ''' </summary>
    Private Sub MessageViewInit()
        'メッセージ列のイニシャライズ
        MessageView.Rows.Add("所属会社")
        MessageView.Rows.Add("所属部署")
        MessageView.Rows.Add("氏名")
        MessageView.Rows.Add("ﾕｰｻﾞ名/ﾌﾟﾛｼﾞｪｸﾄ名")

        'companyCellの追加
        Dim companyCell = CType(MessageView.Rows(0).Cells(1), DataGridViewComboBoxCell)
        Dim sql = "select c_name,c_id from companys"
        Dim table = GetData(sql)
        companyCell.DataSource = table
        companyCell.DisplayMember = "c_name"
        companyCell.ValueMember = "c_id"
        'MessageView.Rows(0).Cells(1) = companyCell

        'userCellの追加
        Dim userCell = CType(MessageView.Rows(3).Cells(1), DataGridViewComboBoxCell)
        userCell.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing
        Dim sql1 = "select u_name,u_id from users"
        Dim table1 = GetData(sql1)
        userCell.DataSource = table1
        userCell.DisplayMember = "u_name"
        userCell.ValueMember = "u_id"
        'MessageView.Rows(3).Cells(1) = userCell
    End Sub

    ''' <summary>
    ''' データベースからデータを取り出す
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="args"></param>
    ''' <returns></returns>
    Private Function GetData(sql As String, ParamArray args As String()) As DataTable

        'sql句の構成
        Dim sql1 = ""
        If args.Length = 0 Then
            sql1 &= sql
        Else
            Dim arr = Split(sql, "?")
            For i As Integer = 0 To arr.Length - 1

                sql1 &= arr(i)
                If i < args.Length Then
                    sql1 &= " '" & args(i) & "' "
                End If
            Next i
        End If

        'sql句の実行
        Dim dataAdapter As SqlDataAdapter = New SqlDataAdapter(sql1, connection)
        Dim dateSet As DataSet = New DataSet()
        dataAdapter.Fill(dateSet)
        Return dateSet.Tables(0)
    End Function

    ''' <summary>
    ''' データベースにデータを書き入れ
    ''' </summary>
    ''' <param name="sql"></param>
    ''' <param name="args"></param>
    ''' <returns></returns>
    Private Function SetData(sql As String, ParamArray args As String()) As Integer

        'sql句の構成
        Dim sql1 = ""
        If args.Length = 0 Then
            sql1 &= sql
        Else
            Dim arr = Split(sql, "?")
            For i As Integer = 0 To arr.Length - 1

                sql1 &= arr(i)
                If i < args.Length Then
                    sql1 &= " '" & args(i) & "' "
                End If
            Next i
        End If

        'sql句の実行
        Dim dataCommand As SqlCommand = New SqlCommand(sql1, connection)
        Return dataCommand.ExecuteNonQuery()
    End Function

    ''' <summary>
    ''' MessageViewチェンジイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub MessageViewChange(sender As Object, e As EventArgs) Handles MessageView.CurrentCellDirtyStateChanged
        '重要な情報を取り出す
        Dim index = MessageView.CurrentCell.RowIndex
        Dim value = MessageView.Rows(index).Cells("MessageList").Value
        Dim cname As String = MessageView.Rows(0).Cells("MessageList").Value
        Dim dname As String = MessageView.Rows(1).Cells("MessageList").Value


        If value <> Nothing Then
            Select Case index
                'departmentCellの追加
                Case 0
                    MessageView.Rows(1).Cells(1) = New DataGridViewComboBoxCell
                    Dim departmentCell = CType(MessageView.Rows(1).Cells(1), DataGridViewComboBoxCell)
                    departmentCell.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing
                    'departmentCell.DataSource = Nothing
                    'departmentCell.DisplayMember = Nothing
                    'departmentCell.ValueMember = Nothing
                    Dim sql = "select d_name,d_id from departments where c_id = ?"
                    Dim cell = CType(MessageView.Rows(0).Cells(1), DataGridViewComboBoxCell)
                    Dim table = GetData(sql, cell.Value)
                    departmentCell.DataSource = table
                    departmentCell.DisplayMember = "d_name"
                    departmentCell.ValueMember = "d_id"
                    'MessageView.Rows(1).Cells(1) = departmentCell
                    'MessageView.AllowUserToResizeRows = False

                'nameCellの追加
                Case 1
                    MessageView.Rows(2).Cells(1) = New DataGridViewComboBoxCell
                    Dim nameCell = CType(MessageView.Rows(2).Cells(1), DataGridViewComboBoxCell)
                    nameCell.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing
                    'nameCell.DataSource = Nothing
                    'nameCell.DisplayMember = Nothing
                    'nameCell.ValueMember = Nothing
                    Dim sql = "select e_name,e_id from employees where d_id = ?"
                    Dim cell = CType(MessageView.Rows(1).Cells(1), DataGridViewComboBoxCell)
                    Dim table = GetData(sql, cell.Value)
                    nameCell.DataSource = table
                    nameCell.DisplayMember = "e_name"
                    nameCell.ValueMember = "e_id"
                    'MessageView.Rows(2).Cells(1) = nameCell
                Case 2
                    SealViewInit()
            End Select
        End If
    End Sub

    ''' <summary>
    ''' ReportViewの初期化
    ''' </summary>
    Private Sub ReportViewInit()
        ReportView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells

        ReportView.Rows.Add(32)

        ReportView.Rows(31).Cells(0).Value = "合計"
        ReportView.Rows(31).Cells(3).Value = "0:00"
    End Sub

    ''' <summary>
    ''' 年度と月度の初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub YearMonViewChange(sender As Object, e As EventArgs) Handles YearMonView.CurrentCellDirtyStateChanged
        Dim yearVal = YearMonView.Rows(0).Cells(0).Value
        Dim monVal = YearMonView.Rows(0).Cells(1).Value

        If yearVal <> "年度" And monVal <> "月度" Then
            Dim year = CType(YearMonView.Rows(0).Cells(0).Value, Integer)
            Dim mon = CType(YearMonView.Rows(0).Cells(1).Value, Integer)
            Dim day = Getdays(year, mon)

            '年度か月度の変更する時は、starttime、endtimeとworktimeは全部で削除する
            For i = 0 To 30
                ReportView.Rows(i).SetValues(Nothing, Nothing, Nothing, Nothing)
                ReportView.Rows(i).Cells(0).Style.ForeColor = Black.Color
                ReportView.Rows(i).Cells(3).Style.ForeColor = Black.Color
                'ReportView.Rows(i).Cells(0).Value = Nothing
                'ReportView.Rows(i).Cells(1).Value = Nothing
                'ReportView.Rows(i).Cells(2).Value = Nothing
                'ReportView.Rows(i).Cells(3).Value = Nothing
            Next i

            For i As Integer = 0 To day - 1
                Dim nowDate = New DateTime(year, mon, i + 1, 0, 0, 0)
                Dim oldDate As DateTime = New DateTime(year, 1, 1, 0, 0, 0)
                Dim days = Split((nowDate - oldDate).ToString(), ".")(0)
                If days = "00:00:00" Then
                    days = 0
                End If
                Dim monNum As Integer = (year - 1 + Int((year - 1) / 4) - Int((year - 1) / 100) + Int((year - 1) / 400) + days + 1) Mod 7
                Select Case monNum
                    Case 0
                        ReportView.Rows(i).Cells(0).Style.ForeColor = Red.Color
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (日)"
                    Case 1
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (月)"
                    Case 2
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (火)"
                    Case 3
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (水)"
                    Case 4
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (木)"
                    Case 5
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (金)"
                    Case 6
                        ReportView.Rows(i).Cells(0).Style.ForeColor = Blue.Color
                        ReportView.Rows(i).Cells(0).Value = (i + 1) & " (土)"
                End Select
            Next i



            ''総時間を計算
            'SumViewInit()
        End If
    End Sub

    ''' <summary>
    ''' ReportView中のworktimeを設定
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ReportViewWorkTime(sender As Object, e As EventArgs) Handles ReportView.CurrentCellDirtyStateChanged
        '重要な情報を取り出す
        Dim startTime = ReportView.CurrentRow.Cells(1).Value
        Dim endTime = ReportView.CurrentRow.Cells(2).Value

        'starttimeとendtimeはnothingじゃないと、以下のstatementを実行する
        If startTime <> "" And endTime <> "" Then
            startTime = Split(startTime, ":")
            endTime = Split(endTime, ":")
            Dim workTime = ""

            startTime = New TimeSpan(startTime(0), startTime(1), 0)
            endTime = New TimeSpan(endTime(0), endTime(1), 0)
            If endTime > startTime Then
                Dim arr = Split((endTime - startTime).ToString, ":")
                Dim num = arr(0) / 6
                If num > 1 Or (num = 1 And arr(1) > 0) Then
                    workTime = (CType(arr(0), Integer) - Int(num) * 1) & ":" & arr(1)
                Else
                    workTime = CType(arr(0), Integer) & ":" & arr(1)
                End If

            Else
                workTime = "エラー"
                ReportView.CurrentRow.Cells(3).Style.ForeColor = Red.Color
            End If
            ReportView.CurrentRow.Cells(3).Value = workTime


            GetSumTime()
        ElseIf startTime = "" And endTime = "" Then
            ReportView.CurrentRow.Cells(3).Value = ""
        End If
    End Sub

    '''' <summary>
    '''' 総時間を計算
    '''' </summary>
    'Private Sub SumViewInit()
    '    SumView.Rows(0).Cells(0).Value = "合計"
    '    SumView.Rows(0).Cells(3).Value = "0:00"
    'End Sub

    ''' <summary>
    ''' 通勤時間の初期化
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub WorkTimeListChanged(sender As Object, e As EventArgs) Handles WorkTimeList.SelectedIndexChanged
        Dim workTime = WorkTimeList.Text
        Dim year = YearMonView.Rows(0).Cells(0).Value
        Dim mon = YearMonView.Rows(0).Cells(1).Value

        If year <> "" And mon <> "" Then
            year = CType(YearMonView.Rows(0).Cells(0).Value, Integer)
            mon = CType(YearMonView.Rows(0).Cells(1).Value, Integer)

            Dim arr = workTime.Split(":")
            Dim days As Integer = Getdays(year, mon)
            For i = 0 To days - 1
                Dim color = ReportView.Rows(i).Cells(0).Style.ForeColor
                If color <> Red.Color And color <> Blue.Color Then
                    Dim endTime As Integer = CType(arr(0), Integer) + 9
                    ReportView.Rows(i).Cells(1).Value = workTime
                    ReportView.Rows(i).Cells(2).Value = endTime.ToString() & ":" & arr(1)
                    ReportView.Rows(i).Cells(3).Value = "8:00"
                End If
            Next i
            GetSumTime()
        End If
    End Sub

    ''' <summary>
    ''' 総時間を取り出す
    ''' </summary>
    Private Sub GetSumTime()
        Dim sumHour = 0
        Dim sumMin = 0
        For i = 0 To 30
            Dim time = Split(ReportView.Rows(i).Cells(3).Value, ":")
            If time.Length = 2 Then
                sumHour += CType(time(0), Integer)
                sumMin += CType(time(1), Integer)
            End If
        Next i

        sumHour += Int(sumMin / 60)
        sumMin = sumMin Mod 60
        Dim min = sumMin.ToString()
        If sumMin = 0 Then
            min = "00"
        End If
        Dim sumTime = sumHour & ":" & min

        ReportView.Rows(31).Cells(3).Value = sumTime
    End Sub

    ''' <summary>
    ''' 本月の日数を取り出す
    ''' </summary>
    ''' <param name="year"></param>
    ''' <param name="mon"></param>
    ''' <returns></returns>
    Private Function Getdays(year As String, mon As String)
        Dim day = 0
        Select Case mon
            Case 1, 3, 5, 7, 8, 10, 12
                day = 31
            Case 4, 6, 9, 11
                day = 30
            Case 2
                If year Mod 4 <> 0 Then
                    day = 28
                Else
                    day = 29
                End If
        End Select
        Return day
    End Function

    ''' <summary>
    ''' メッセージを登録する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        Dim year = YearMonView.Rows(0).Cells(0).Value
        Dim mon = YearMonView.Rows(0).Cells(1).Value
        Dim cid = MessageView.Rows(0).Cells(1).Value
        Dim did = MessageView.Rows(1).Cells(1).Value
        Dim eid = MessageView.Rows(2).Cells(1).Value

        If year <> Nothing And mon <> Nothing And cid <> Nothing And did <> Nothing And eid <> Nothing Then
            Dim e_id As Integer = MessageView.Rows(2).Cells(1).Value
            Dim r_date As String = YearMonView.Rows(0).Cells(0).Value & "/" & YearMonView.Rows(0).Cells(1).Value
            Dim sql = "select r_id from reports where e_id = ? and r_date = ?"
            Dim table = GetData(sql, e_id, r_date)
            Dim num = UpdateReports(table, e_id, r_date)
            Dim r_id = GetData(sql, e_id, r_date).Rows(0).ItemArray(0).ToString()
            Dim num1 = UpdateReportsDetail(table, r_id, year, mon)
            MessageBox.Show("Reports表の中の影響される行目：" & num & vbLf & "ReportsDetail表の中の影響される行目：" & num1)
        End If

    End Sub

    ''' <summary>
    ''' Reports表に対して更新する
    ''' </summary>
    ''' <param name="table"></param>
    ''' <param name="e_id"></param>
    ''' <param name="r_date"></param>
    Private Function UpdateReports(table As DataTable, e_id As Integer, r_date As String) As Integer
        Dim sql = "insert into reports values (next value for reports_sequence,?,?,?,?,?,?,?)"
        If table.Rows.Count > 0 Then
            sql = "update reports set u_id = ?,e_id = ?,r_date = ?,total_worktime = ?,overtime = ?,important_content = ?,create_time = ? where r_id = " & table.Rows(0).ItemArray(0)
        End If
        Dim u_id As Integer = MessageView.Rows(3).Cells(1).Value
        Dim total_worktime As String = ReportView.Rows(31).Cells(3).Value
        Dim important_content = WorkText.Text
        Dim now = Date.Now()
        Return SetData(sql, u_id, e_id, r_date, total_worktime, total_worktime, important_content, now)
        'Console.WriteLine("実行行目：" & int)
    End Function

    ''' <summary>
    ''' ReportsDetail表に対して更新する
    ''' </summary>
    ''' <param name="table"></param>
    ''' <param name="r_id"></param>
    ''' <param name="year"></param>
    ''' <param name="mon"></param>
    Private Function UpdateReportsDetail(table As DataTable, r_id As String, year As Integer, mon As Integer) As Integer
        Dim days = Getdays(year, mon)
        Dim sql = "insert into reports_detail values (?,?,?,?,?)"
        If table.Rows.Count > 0 Then
            Dim sql1 = "delete from reports_detail where r_id = " & table.Rows(0).ItemArray(0)
            SetData(sql1)
        End If
        Dim sum = 0
        For i = 0 To days - 1
            Dim time = ReportView.Rows(i).Cells(3).Value
            If time <> Nothing Then
                Dim arr = time.ToString().Split(":")
                If arr.Length > 1 Then
                    Dim startArr = ReportView.Rows(i).Cells(1).Value.ToString().Split(":")
                    Dim startTime = New DateTime(year, mon, i + 1, startArr(0), startArr(1), 0)
                    Dim endArr = ReportView.Rows(i).Cells(2).Value.ToString().Split(":")
                    Dim endTime = New DateTime(year, mon, i + 1, endArr(0), endArr(1), 0)
                    Dim workTime = ReportView.Rows(i).Cells(3).Value.ToString()
                    Dim workContent = ReportView.Rows(i).Cells(4).Value
                    sum += SetData(sql, r_id, startTime, endTime, workTime, workContent)
                End If

            End If
        Next i
        'Console.WriteLine("実行行目：" & sum)
        Return sum
    End Function

    Private Sub SealViewInit()

        Dim column1 = CType(SealView.Columns(0), DataGridViewImageColumn)
        Dim column2 = CType(SealView.Columns(1), DataGridViewImageColumn)
        Dim column3 = CType(SealView.Columns(2), DataGridViewImageColumn)
        column1.Image = seal
        column2.Image = seal
        column3.Image = seal
        'Dim cell = CType(SealView.CurrentRow.Cells(0), DataGridViewImageCell)
        'Dim column = CType(cell, DataGridViewImageColumn)
        'Dim column = New DataGridViewImageColumn
        'Dim img = New Bitmap("C:\Users\zzq\Desktop\tyou.png")
        'column.Image = img
    End Sub

    Private Sub SealView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles SealView.CellContentClick

        Dim column1 = CType(SealView.Columns(0), DataGridViewImageColumn)
        Dim column2 = CType(SealView.Columns(1), DataGridViewImageColumn)
        Dim column3 = CType(SealView.Columns(2), DataGridViewImageColumn)

        If column1.Image Is seal And column2.Image Is seal And column3.Image Is seal Then
            Dim e_id = MessageView.Rows(2).Cells(1).Value
            If e_id <> Nothing Then
                Dim sql = "select u_id,p_id,seal from employees where e_id = ?"
                Dim table = GetData(sql, e_id)
                Dim row = table.Rows(0)
                If row.ItemArray(0).ToString <> Nothing Then
                    Dim column = CType(SealView.Columns(2), DataGridViewImageColumn)
                    column.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                End If

                Select Case row.ItemArray(1)
                    Case 2
                        Dim column = CType(SealView.Columns(0), DataGridViewImageColumn)
                        column.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                    Case 3
                        Dim column = CType(SealView.Columns(1), DataGridViewImageColumn)
                        column.Image = New Bitmap("../../Resources/" & row.ItemArray(2).ToString)
                End Select
            End If
        Else
            SealViewInit()
        End If
    End Sub
End Class
